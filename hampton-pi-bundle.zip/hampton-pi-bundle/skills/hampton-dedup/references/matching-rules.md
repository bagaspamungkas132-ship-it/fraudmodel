# Matching rules & ide pengembangan - Hampton

## Daftar isi
1. Normalisasi nama
2. Normalisasi field lain
3. Blocking (supaya tidak O(n x m))
4. Edge case yang wajib dipikirkan
5. Data quality checks
6. QA dan tuning
7. Ide tambahan

## 1. Normalisasi nama (`scripts/namematch.py`)
- Uppercase, buang aksen dan tanda baca; `A.R.` dipecah jadi inisial `A R`.
- Gelar depan (Dr, Ir, H, Hj, Prof, Drs, Ibu, Bapak, Tn, Ny, KH, ...) dibuang hanya di posisi awal.
- Gelar belakang (S.E., SH, S.Kom, M.M., MBA, ST, Ak, CPA, ...) dibuang hanya di posisi akhir, termasuk yang ditulis tanpa titik (`BUDI SANTOSO SE`). Gelar ambigu (MA, ME, BA, CA, AK) hanya dibuang kalau ada titik/koma sebagai bukti.
- `BIN/BINTI/BT` dibuang.
- Ejaan: oe->u, dj->j, tj->c, sj->sy, dh->d, th->t, ph->f, huruf dobel, y->i. Varian Muhammad (Moh, Muh, Mhd, Mohammad, Muhamad, Mochamad, ...) -> MUHAMMAD; Abd -> Abdul.
- Skor: pasangan token terbaik (greedy). Typo = rasio >= 0.8; inisial = 0.9; nama terpotong (prefix) = 0.88. Urutan terbalik kena penalti kecil 0.97. Nama pendek vs panjang kena penalti jumlah kata. Satu kata saja maksimal 0.75. Kecocokan hanya lewat inisial maksimal 0.6.
- Tambah kamus (gelar, varian nama) di bagian atas file kalau ketemu kasus baru, lalu tambahkan test.

## 2. Normalisasi field lain
- **DOB**: parse banyak format ke YYYY-MM-DD; asumsi DD/MM/YYYY. Flag `dob_invalid` dan `dob_placeholder` (1900-01-01, 1970-01-01). Near-match: hari-bulan tertukar atau satu komponen beda.
- **ID Number**: buang spasi/tanda baca. NIK = 16 digit. WNA: paspor/KITAS alfanumerik, jangan dipaksa 16 digit. Near-match: beda 1 digit atau 2 digit bersebelahan tertukar.
- **Cek silang NIK vs DOB**: digit 7-12 NIK = DDMMYY, perempuan hari +40. Kalau tidak cocok dengan DOB, flag `nik_vs_dob_tidak_cocok` - membantu menentukan field mana yang salah saat near-match.
- **NPWP**: ambil digit saja (15 atau 16 digit). Untuk wajib pajak orang pribadi NIK kini lazim dipakai sebagai NPWP, jadi NPWP bisa sama dengan NIK; cek silang NPWP vs NIK sebagai pengembangan.
- **SID**: alfanumerik uppercase, bandingkan exact.
- **HP**: digit saja; 08xx / 8xx / +62 / 620 -> 628xx. **Email**: lowercase.
- **Nama ibu**: pakai fungsi nama yang sama, ambang yang sama.

## 3. Blocking
Kandidat OCBC untuk tiap record HSBC diambil dari index: ID exact; separuh pertama dan separuh kedua ID (salah 1 digit pasti menyisakan satu separuh sama); SID; NPWP; HP; email; DOB (disaring pakai kemiripan 3 huruf awal token nama). HP/email yang muncul di lebih dari 20 record dianggap shared dan diabaikan. Untuk skala produksi, pertahankan key yang sama di SQL/DuckDB.

## 4. Edge case
- **Kembar**: nama mirip + DOB sama + ibu sama tapi ID beda -> REVIEW, bukan match.
- **Ayah-anak / Jr-Sr**: nama sama, DOB beda -> bukan match (DOB primary).
- **Nama berubah setelah menikah / ganti nama**: ID sama, nama beda -> REVIEW, jangan auto-reject.
- **Nama satu kata** (umum di Indonesia): skor dibatasi 0.75, butuh primary lain.
- **Nama terpotong** (batas panjang field core banking): ditangani lewat aturan prefix.
- **WNA**: nama bisa dalam urutan Barat/Tionghoa terbalik; ID paspor.
- **Satu orang, banyak CIF di HSBC** (rekening gabungan, produk berbeda): jangan kirim welcome pack dobel - dedup internal HSBC juga.
- **Nama sama persis, orang beda**: tanpa DOB + ID jangan pernah MATCH.

## 5. Data quality (dilaporkan, bukan ditebak)
Null rate per field, ID bukan 16 digit, NIK vs DOB tidak cocok, DOB placeholder/invalid, nama kosong, HP/email shared, duplikat internal. Kualitas data yang buruk menjelaskan banyak REVIEW; laporkan ke owner data.

## 6. QA dan tuning
- Buat golden set kecil berlabel manual (campur MATCH, kembar, near-miss, NO_MATCH). Ukur precision dan recall per status.
- Biaya salah tidak simetris: false MATCH (tidak kirim ke orang baru) vs false NO_MATCH (kirim welcome pack ke nasabah existing / data bocor ke orang salah). Diskusikan dengan owner mana yang lebih mahal sebelum menggeser threshold.
- Simpan `rule_version`, dan jangan ubah threshold tanpa mencatat alasannya.

## 7. Ide tambahan (belum diimplementasi, diskusikan dulu dengan user)
1. **Exclusion list** sebelum kirim: nasabah meninggal, minor tanpa wali, do-not-contact, alamat tidak valid, rekening sudah tutup.
2. **Cek alamat kirim**: kalau nasabah sudah punya welcome pack/komunikasi OCBC, hindari kirim ganda; cocokkan alamat sebagai penguat tambahan (jangan primary).
3. **Reviewer worksheet**: file review berisi pasangan side-by-side (di-mask), skor, reason, kolom keputusan, supaya hasil review bisa dimasukkan kembali ke pipeline.
4. **Feedback loop**: keputusan manual reviewer disimpan sebagai pasangan berlabel, dipakai untuk tuning dan regression test.
5. **Reconciliation**: jumlah HSBC masuk = jumlah keluar per status; tidak ada record hilang atau terduplikasi di output.
6. **Audit pack**: input file hash, rule_version, parameter, jumlah per status, tanggal run, siapa yang menjalankan.
7. **Pseudonymization** untuk lingkungan dev/test (hash NIK dengan salt) supaya tim lain bisa debug tanpa PII.
8. **Incremental run**: karena penyelesaian transaksi ditargetkan 2027, data HSBC/OCBC akan berubah; jadwalkan re-run dan bandingkan dengan run sebelumnya (siapa yang berubah status).
9. **Perbandingan fonetik** tambahan (mis. Double Metaphone tidak ideal untuk nama Indonesia; lebih baik kamus varian lokal yang terus ditambah dari hasil QA).

Catatan: validasi dan parsing HP/email/alamat ada di skill terpisah `hampton-validate-contact`. Di skill ini HP/email hanya dibersihkan (`contactclean.py`) agar nomor/email dummy tidak jadi penguat match.
