# Rubrik penilaian nama (hampton-name-judge) - versi nj-1.0

Dipakai untuk menilai pasangan nama zona abu-abu secara BUTA: hanya dua nama, tanpa DOB, ID, atau data lain.
Contoh di bawah SINTETIS (bukan data nasabah). Jangan menaruh nama nasabah asli di file ini.

## Keluaran per pasangan (CSV, satu baris per pair_key)
`pair_key,verdict,case_type,confidence,reason,prompt_version`
- verdict: `SAME` | `DIFFERENT` | `UNSURE` (huruf besar persis)
- case_type: salah satu: `terpotong`, `singkatan`, `inisial_beberapa_kata`, `spasi`, `ejaan_lama_baru`, `ejaan_tionghoa`, `ejaan_arab_islami`,
  `typo_1_huruf`, `kata_tengah_hilang`, `urutan_terbalik`, `gelar`, `nama_daerah`, `ganti_nama`, `akhiran_gender`, `generasi`, `nama_berbeda`, `lainnya`
- confidence: 0.0-1.0 (jujur; di bawah 0.6 sebaiknya UNSURE)
- reason: satu kalimat, maksimal 140 karakter, tanpa mengutip ulang nama lengkap
- prompt_version: `nj-1.0`

## Prinsip
1. Nilai hanya pola penulisan nama. Jangan menebak dari etnis, agama, atau asumsi tentang orangnya.
2. `SAME` hanya bila setiap perbedaan dapat dijelaskan oleh satu pola yang wajar DAN tidak ada kata inti yang berbeda tanpa penjelasan.
3. Kata inti berbeda 1-2 huruf pada kata pendek (mis. empat huruf) padahal semua kata lain identik: bisa typo, bisa orang lain (saudara, nama mirip) -> `UNSURE` kecuali ada pola ejaan yang jelas.
4. Perbedaan tegas -> `DIFFERENT`: akhiran gender berbeda (-an vs -ati), generasi (Jr/Sr/II/III), kata nama yang berbeda total.
5. Dugaan ganti nama (menikah, alias, nama panggilan) -> `UNSURE`, case_type `ganti_nama`.
6. Singkatan wajar: inisial, kependekan kata ("NGR" untuk Ngurah), inisial beberapa kata ("HM" untuk dua kata), nama terpotong di akhir field.
7. Semua kata lain harus cocok. Satu kata cocok parsial tidak cukup bila kata lain berbeda.
8. Bila ragu, pilih `UNSURE`. UNSURE aman: status tidak naik, manusia memutuskan.

## Contoh sintetis (pola -> verdict)
| Nama A | Nama B | verdict | case_type |
|---|---|---|---|
| BUDI TRESNA UT | BUDI TRESNA UTAMA | SAME | terpotong |
| SITI WIDYA CH K | SITI WIDYA CHRISTIANA KESUMA | SAME | singkatan |
| DEWI ANGELA HM | DEWI ANGELA HENRIKA MAUREN | SAME | inisial_beberapa_kata |
| IDA BAGUS NGR PRAMANA | IDA BAGUS NGURAH PRAMANA | SAME | singkatan |
| TONO PUJI ASTUTI | TONO PUJIASTUSI | SAME | spasi |
| ANDI NATALIJA KUSUMA PUTERI | ANDI NATALIA KUSUMAPUTRI | SAME | ejaan_lama_baru |
| CHEN LING CANDRA | CHEN LIE CANDRA | UNSURE | ejaan_tionghoa |
| RIZKI IMAM P SUTAN | RIZKI IMAN P SUTAN | UNSURE | typo_1_huruf |
| DEVI PERMATA SARI NASUTION | DESI PERMATA SARI NASUTION | UNSURE | typo_1_huruf |
| SITI AMINAH WULANDARI | SITI AMINAH SANTOSO | UNSURE | ganti_nama |
| DEDI KURNIAWAN | DEDI KURNIAWATI | DIFFERENT | akhiran_gender |
| BUDI SANTOSO JR | BUDI SANTOSO SR | DIFFERENT | generasi |
| AHMAD FAUZI | BUDI WIJAYA | DIFFERENT | nama_berbeda |

Catatan: contoh "CHEN LING / LIE" UNSURE karena kata inti berbeda; bila organisasi memutuskan kamus ejaan Tionghoa-Indonesia, pasangan yang ada di kamus itu naik ke SAME oleh rule (tahap 1), bukan oleh judge.
