#!/usr/bin/env python3
"""Tes end-to-end tahap rule -> judge (palsu) -> apply -> checker. Data sintetis. Jalankan: python test_pipeline.py"""
import csv, json, os, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
tmp = tempfile.mkdtemp()
H = ["CIF", "NAMA", "TGL_LAHIR", "NIK", "SID", "NPWP", "IBU_KANDUNG", "HP", "EMAIL"]
def nik(d, m, y, s): return f"3171{10 + s:02d}{d:02d}{m:02d}{y % 100:02d}{s:04d}"
O = [  # nasabah OCBC
    ["O1", "BUDI SANTOSO", "1985-03-12", nik(12, 3, 1985, 1), "", "", "SITI", "", ""],
    ["O2", "RIZKI IMAM P SUTAN", "1990-07-25", nik(25, 7, 1990, 2), "", "", "WATI", "", ""],
    ["O3", "DEDI KURNIAWAN", "1980-01-10", nik(10, 1, 1980, 3), "", "", "RINI", "", ""],
    ["O4", "DEVI PERMATA SARI NASUTION", "1992-05-05", nik(5, 5, 1992, 4), "", "", "RINA", "", ""],
    ["O5", "M ZAKI ARI ANWAR", "1988-08-08", nik(8, 8, 1988, 5), "", "", "ANI", "", ""],
    ["O6", "DWI ROHMAH YUNI ASTUTI", "1991-02-02", nik(2, 2, 1991, 6), "", "", "SRI", "", ""],
]
Hs = [  # nasabah HSBC
    ["H1", "BUDI SANTOSO", "1985-03-12", nik(12, 3, 1985, 1), "", "", "SITI", "", ""],                 # MATCH rule
    ["H2", "RIZKI IMAN P SUTAN", "1990-07-25", nik(25, 7, 1990, 2), "", "", "WATI", "", ""],            # weak -> judge SAME -> MATCH
    ["H3", "DEDI KURNIAWATI", "1980-01-10", nik(10, 1, 1980, 3), "", "", "RINI", "", ""],               # hint -> REVIEW, tidak masuk antrean
    ["H4", "DESI PERMATA SARI NASUTION", "1992-05-05", nik(5, 5, 1992, 4), "", "", "RINA", "", ""],     # weak -> judge DIFFERENT -> REVIEW
    ["H5", "M ZAKI ABI ANWAR", "1988-08-08", nik(8, 8, 1988, 5), "", "", "ANI", "", ""],                # weak -> judge UNSURE -> tetap
    ["H6", "DWI ROHMAH ZUNI ASTUTI", "1991-12-12", nik(2, 2, 1991, 6), "", "", "SRI", "", ""],          # weak + DOB beda: SAME tidak boleh jadi MATCH
    ["H7", "ORANG BARU", "1970-01-01", nik(1, 1, 1970, 7), "", "", "X", "", ""],                         # NO_MATCH
]
def w(p, rows):
    with open(p, "w", newline="") as f:
        c = csv.writer(f); c.writerow(H); c.writerows(rows)
w(f"{tmp}/o.csv", O); w(f"{tmp}/h.csv", Hs)
json.dump({"hsbc": dict(zip(["rec_id", "name", "dob", "id_number", "sid", "npwp", "mother_name", "phone", "email"], H)),
           "ocbc": dict(zip(["rec_id", "name", "dob", "id_number", "sid", "npwp", "mother_name", "phone", "email"], H))}, open(f"{tmp}/m.json", "w"))
def run(*a, ok=(0,)):
    r = subprocess.run([sys.executable, *a], cwd=HERE, capture_output=True, text=True)
    assert r.returncode in ok, (a, r.returncode, r.stdout[-400:], r.stderr[-400:])
    return r
bad = 0
def check(label, cond):
    global bad
    if not cond:
        bad += 1; print("FAIL", label)

run("dedup.py", "--hsbc", f"{tmp}/h.csv", "--ocbc", f"{tmp}/o.csv", "--map", f"{tmp}/m.json", "--out", f"{tmp}/r.csv", "--judge-queue", f"{tmp}/q.csv")
st = {r["hsbc_rec_id"]: r["status"] for r in csv.DictReader(open(f"{tmp}/r.csv"))}
check("rule H1 MATCH", st["H1"] == "MATCH"); check("rule H3 REVIEW", st["H3"] == "REVIEW"); check("rule H7 NO_MATCH", st["H7"] == "NO_MATCH")
q = list(csv.DictReader(open(f"{tmp}/q.csv")))
check("antrean hanya nama (tanpa DOB/ID)", set(q[0].keys()) == {"pair_key", "name_a", "name_b", "rule_score", "rule_tier", "rule_notes"})
names = {r["name_a"]: r for r in q}
check("H3 (hint) tidak masuk antrean", "DEDI KURNIAWATI" not in names)
check("antrean berisi 4 pasangan abu-abu", len(q) == 4)
V = {"RIZKI IMAN P SUTAN": "SAME", "DESI PERMATA SARI NASUTION": "DIFFERENT", "M ZAKI ABI ANWAR": "UNSURE", "DWI ROHMAH ZUNI ASTUTI": "SAME"}
with open(f"{tmp}/j.csv", "w", newline="") as f:
    c = csv.writer(f); c.writerow(["pair_key", "verdict", "case_type", "confidence", "reason", "prompt_version"])
    for r in q: c.writerow([r["pair_key"], V[r["name_a"]], "typo_nama", "0.8", "uji", "nj-1.0"])
run("apply_name_judgments.py", "--result", f"{tmp}/r.csv", "--judgments", f"{tmp}/j.csv", "--out", f"{tmp}/f.csv", "--cache", f"{tmp}/cache.csv")
fin = {r["hsbc_rec_id"]: r for r in csv.DictReader(open(f"{tmp}/f.csv"))}
check("H2 SAME + DOB&ID -> MATCH", fin["H2"]["status"] == "MATCH" and fin["H2"]["decision_basis"] == "RULE+LLM")
check("H4 DIFFERENT -> REVIEW", fin["H4"]["status"] == "REVIEW")
check("H5 UNSURE -> status tidak berubah", fin["H5"]["status"] == fin["H5"]["status_rule"])
check("H6 SAME tanpa DOB cocok -> BUKAN MATCH", fin["H6"]["status"] != "MATCH")
check("cache terisi", len(list(csv.DictReader(open(f"{tmp}/cache.csv")))) == 4)
rc = run("check_result.py", "--result", f"{tmp}/f.csv", "--hsbc", f"{tmp}/h.csv", "--map", f"{tmp}/m.json", "--out-dir", f"{tmp}/c", "--llm-sample", "9", ok=(0,))
rep = json.load(open(f"{tmp}/c/check_report.json"))
check("checker PASS pada hasil benar", rep["overall"] in ("PASS", "PASS_WITH_WARNINGS") and not any(c["status"] == "FAIL" for c in rep["checks"]))
# penilaian ulang buta (checker setuju) lalu (checker bertentangan)
blind = list(csv.DictReader(open(f"{tmp}/c/llm_resample_blind.csv")))
key = {r["pair_key"]: r["judge_verdict"] for r in csv.DictReader(open(f"{tmp}/c/llm_resample_key.csv"))}
with open(f"{tmp}/c/llm_resample_results.csv", "w", newline="") as f:
    c = csv.writer(f); c.writerow(["pair_key", "verdict"]); [c.writerow([r["pair_key"], key[r["pair_key"]]]) for r in blind]
run("compare_resample.py", "--key", f"{tmp}/c/llm_resample_key.csv", "--resample", f"{tmp}/c/llm_resample_results.csv", "--report", f"{tmp}/c/check_report.json")
flip = {"SAME": "DIFFERENT", "DIFFERENT": "SAME", "UNSURE": "SAME"}
with open(f"{tmp}/c/llm_resample_results.csv", "w", newline="") as f:
    c = csv.writer(f); c.writerow(["pair_key", "verdict"]); [c.writerow([r["pair_key"], flip[key[r["pair_key"]]]]) for r in blind]
r = run("compare_resample.py", "--key", f"{tmp}/c/llm_resample_key.csv", "--resample", f"{tmp}/c/llm_resample_results.csv", "--report", f"{tmp}/c/check_report.json", ok=(1,))
check("kontradiksi resample -> FAIL", json.load(open(f"{tmp}/c/check_report.json"))["overall"] == "FAIL")
# sabotase: UNSURE dipaksa jadi MATCH, dan LLM-SAME tanpa DOB dipaksa MATCH
rows = list(csv.DictReader(open(f"{tmp}/f.csv")))
for r in rows:
    if r["hsbc_rec_id"] in ("H5", "H6"): r["status"] = "MATCH"; r["suggested_action"] = "HOLD_EXISTING_CUSTOMER"
with open(f"{tmp}/bad.csv", "w", newline="") as f:
    c = csv.DictWriter(f, fieldnames=rows[0].keys()); c.writeheader(); c.writerows(rows)
run("check_result.py", "--result", f"{tmp}/bad.csv", "--hsbc", f"{tmp}/h.csv", "--map", f"{tmp}/m.json", "--out-dir", f"{tmp}/c2", ok=(1,))
rep = {c["id"]: c["status"] for c in json.load(open(f"{tmp}/c2/check_report.json"))["checks"]}
check("sabotase terdeteksi C4/C5/C12", rep["C4_match_wajib_3_primary"] == "FAIL" and rep["C5_status_sesuai_aturan"] == "FAIL" and rep["C12_kebijakan_llm_dipatuhi"] == "FAIL")
print("OK" if not bad else f"{bad} gagal")
sys.exit(1 if bad else 0)
