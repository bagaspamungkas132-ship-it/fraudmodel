#!/usr/bin/env python3
"""Fuzzy name comparison for Indonesian person names (v2). Stdlib only.

Tahap 1-2 dari pipeline nama (rule): normalisasi + skor + tier + flag negatif. Tahap 3 (LLM) hanya untuk tier WEAK/DIFFERENT
yang DOB atau ID-nya cocok/hampir cocok (lihat hampton-name-judge).

Usage:  python namematch.py "Dr. Ir. H. Budi Santoso, M.M." "BUDI SANTOSO"
Import: from namematch import name_similarity -> {"score","tier","flags","notes","a_norm","b_norm"}
Tier: EXACT | NORMALIZED | VARIANT (>=NAME_OK) | WEAK (NAME_WEAK..NAME_OK) | DIFFERENT | DIFFERENT_HINT (ada flag negatif tegas)
"""
import json
import re
import sys
import unicodedata
from difflib import SequenceMatcher

NAME_OK = 0.85
NAME_WEAK = 0.70

PREFIX_TITLES = {
    "DR", "DRS", "DRA", "DRG", "IR", "PROF", "PROFESOR", "H", "HJ", "HAJI", "HAJJAH",
    "KH", "KYAI", "IBU", "BAPAK", "BPK", "NY", "NYONYA", "TN", "TUAN", "SDR", "SDRI",
    "MR", "MRS", "MS", "MISS", "DATO", "DATUK",
}
DEGREES = {
    "SE", "SH", "SKOM", "SKOMP", "SSI", "ST", "SPD", "SPSI", "SIP", "SSOS", "SKM", "SKEP",
    "SPT", "SPI", "SHI", "SAG", "SSTP", "SPDI", "SFARM", "APT", "SPOG", "SPA", "SPPD", "SPJP",
    "SPB", "MM", "MBA", "MSI", "MSC", "MT", "MH", "MKOM", "MPD", "MPSI", "MAK", "MKES", "MKM",
    "MPH", "MARS", "MIM", "MSM", "PHD", "CPA", "CFA", "FRM", "CFP", "BSC", "BBA", "BCOM", "LLB",
    "LLM", "MSTAT", "AMD", "AMK", "AMA", "DIPL", "MA", "ME", "BA", "CA", "AK", "DRG",
}
AMBIGUOUS = {"MA", "ME", "BA", "CA", "AK"}
PARTICLES = {"BIN", "BINTI", "BT", "BTE", "BINTE", "BNT"}
ROMAN = {"I", "II", "III", "IV", "V", "VI", "JR", "SR"}
GENERATION = {"II", "III", "IV", "V", "VI", "JR", "SR"}

SPELL = [("OE", "U"), ("DJ", "J"), ("TJ", "C"), ("SJ", "SY"), ("NJ", "NY"), ("DH", "D"),
         ("TH", "T"), ("PH", "F"), ("AA", "A"), ("EE", "E"), ("OO", "O"), ("UU", "U"),
         ("II", "I"), ("Y", "I")]
CANON = {
    "MOH": "MUHAMMAD", "MOHD": "MUHAMMAD", "MUH": "MUHAMMAD", "MHD": "MUHAMMAD",
    "MOHAMMAD": "MUHAMMAD", "MOHAMAD": "MUHAMMAD", "MUHAMAD": "MUHAMMAD",
    "MUHAMMED": "MUHAMMAD", "MOCHAMAD": "MUHAMMAD", "MOCHAMMAD": "MUHAMMAD",
    "MUCHAMMAD": "MUHAMMAD", "MUKHAMMAD": "MUHAMMAD", "MOHAMED": "MUHAMMAD",
    "ABD": "ABDUL",
}
FEMALE_REMAINDER = {"INA", "TINA", "IA", "TIA", "ATI", "WATI"}


def _spell(t):
    if t in ROMAN:
        return t
    for a, b in SPELL:
        t = t.replace(a, b)
    return t


def _tokenize(raw):
    s = unicodedata.normalize("NFKD", str(raw or "")).encode("ascii", "ignore").decode().upper()
    s = s.replace("'", "").replace("`", "").replace("-", " ")
    toks = []
    for pi, part in enumerate(s.split(",")):
        for w in part.split():
            letters = re.sub(r"[^A-Z0-9]", "", w)
            if not letters:
                continue
            evidence = pi > 0 or "." in w.strip(".")
            if (re.fullmatch(r"(?:[A-Z]\.){2,}[A-Z]?\.?", w)
                    and letters not in DEGREES and letters not in PREFIX_TITLES):
                toks.extend((c, False) for c in letters)
            else:
                toks.append((letters, evidence))
    return toks


def normalize_pairs(raw):
    """Return ([(spelled, plain)], notes). spelled = ejaan dinormalisasi; plain = tanpa normalisasi ejaan."""
    toks = _tokenize(raw)
    notes = []
    while len(toks) > 1 and toks[0][0] in PREFIX_TITLES:
        toks.pop(0)
        notes.append("gelar_depan_dibuang")
    while len(toks) > 1 and toks[-1][0] in DEGREES and (toks[-1][0] not in AMBIGUOUS or toks[-1][1]):
        toks.pop()
        notes.append("gelar_belakang_dibuang")
    out = []
    for t, _ in toks:
        if t in PARTICLES:
            continue
        sp = _spell(t)
        out.append((CANON.get(sp, sp), CANON.get(t, t)))
    return out, notes


def normalize_name(raw):
    pairs, notes = normalize_pairs(raw)
    return [s for s, _ in pairs], notes


def _lev(a, b):
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def _subseq(s, t):
    it = iter(t)
    return all(c in it for c in s)


def _ts(a, b, last):
    if a == b:
        return 1.0, "exact"
    if len(a) == 1 or len(b) == 1:
        return (0.9, "initial") if a[0] == b[0] else (0.0, "")
    short, long_ = (a, b) if len(a) <= len(b) else (b, a)
    if last and len(short) >= 2 and long_.startswith(short) and len(short) / len(long_) >= (0.5 if len(short) >= 3 else 0.3):
        return 0.88, "prefix"  # nama terpotong di akhir field
    if (2 <= len(short) <= 4 and len(long_) >= len(short) + 2 and short.isalpha() and short[0] == long_[0]
            and _subseq(short, long_)):
        return 0.85, "abbrev"  # NGR -> NGURAH, AW -> ADIWINOTO
    r = SequenceMatcher(None, a, b).ratio()
    if r >= 0.8:
        return r, "typo"
    if min(len(a), len(b)) >= 3 and max(len(a), len(b)) <= 8 and _lev(a, b) <= 2:
        return 0.7, "near"  # beda 1-2 huruf pada kata pendek: bisa typo, bisa nama lain -> zona abu-abu
    return 0.0, ""


def token_sim(x, y, last=False):
    return max(_ts(x[0], y[0], last), _ts(x[1], y[1], last), key=lambda c: c[0])


def _merge_adjacent(side, other, side_is_a):
    """Gabungkan dua kata berurutan bila hasil gabungan cocok lebih baik dengan satu kata di sisi lain (spasi hilang/lebih)."""
    out, i, merged = [], 0, False
    while i < len(side):
        if i + 1 < len(side) and other:
            m = (side[i][0] + side[i + 1][0], side[i][1] + side[i + 1][1])
            last_m = i + 1 == len(side) - 1
            sm = max(token_sim(m, z, last_m and zi == len(other) - 1)[0] for zi, z in enumerate(other))
            sx = max(token_sim(side[i], z)[0] for z in other)
            sy = max(token_sim(side[i + 1], z)[0] for z in other)
            if sm >= 0.85 and sm > sx and sm > sy:
                out.append(m)
                i += 2
                merged = True
                continue
        out.append(side[i])
        i += 1
    return out, merged


def _multi_initials(src, un_src, dst, un_dst):
    """Token singkatan 2-3 huruf = inisial dari beberapa kata berurutan di sisi lain (HM = HENRIETTA MAUREEN)."""
    found = []
    for i in list(un_src):
        t = src[i][1]
        if not (2 <= len(t) <= 3 and t.isalpha()):
            continue
        for j in range(len(dst) - len(t) + 1):
            run = list(range(j, j + len(t)))
            if all(k in un_dst for k in run) and "".join(dst[k][1][0] for k in run) == t:
                found.append((i, run))
                un_dst = [k for k in un_dst if k not in run]
                break
    return found


def _gender_flag(x, y):
    for a, b in ((x, y), (y, x)):
        if a.endswith("AN") and b.endswith("ATI") and a[:-2] == b[:-3]:
            return True
        if a.endswith("WAN") and b.endswith("WATI") and a[:-3] == b[:-4]:
            return True
        if b.startswith(a) and b[len(a):] in FEMALE_REMAINDER and len(a) >= 3:
            return True
    return False


def name_similarity(a, b):
    pa, na = normalize_pairs(a)
    pb, nb = normalize_pairs(b)
    notes = sorted(set(na + nb))
    res = {"score": 0.0, "tier": "DIFFERENT", "flags": [], "a_norm": " ".join(s for s, _ in pa),
           "b_norm": " ".join(s for s, _ in pb), "notes": notes}
    if not pa or not pb:
        res["notes"].append("nama_kosong")
        return res
    ta, tb = [s for s, _ in pa], [s for s, _ in pb]
    raw_eq = re.sub(r"\s+", " ", str(a).upper().strip()) == re.sub(r"\s+", " ", str(b).upper().strip())
    if ta == tb:
        res.update(score=1.0, tier="EXACT" if raw_eq else "NORMALIZED")
        return res
    if "".join(ta) == "".join(tb):
        res.update(score=0.95, tier="VARIANT")
        res["notes"].append("spasi_beda")
        return res
    pa, ma = _merge_adjacent(pa, pb, True)
    pb, mb = _merge_adjacent(pb, pa, False)
    if ma or mb:
        notes.append("spasi_beda")
    ta, tb = [s for s, _ in pa], [s for s, _ in pb]
    pairs = sorted(((*token_sim(x, y, i == len(pa) - 1 and j == len(pb) - 1), i, j)
                    for i, x in enumerate(pa) for j, y in enumerate(pb)), reverse=True)
    ui, uj, matched = set(), set(), []
    for sim, kind, i, j in pairs:
        if sim > 0 and i not in ui and j not in uj:
            ui.add(i)
            uj.add(j)
            matched.append(([i], [j], sim, kind))
    un_a = [i for i in range(len(pa)) if i not in ui]
    un_b = [j for j in range(len(pb)) if j not in uj]
    for i, run in _multi_initials(pa, un_a, pb, un_b):
        matched.append(([i], run, 0.9, "initials_multi"))
        ui.add(i)
        uj.update(run)
    un_a = [i for i in range(len(pa)) if i not in ui]
    un_b = [j for j in range(len(pb)) if j not in uj]
    for j, run in _multi_initials(pb, un_b, pa, un_a):
        matched.append((run, [j], 0.9, "initials_multi"))
        uj.add(j)
        ui.update(run)
    eff_a = len(pa) - sum(len(m[0]) - 1 for m in matched)
    eff_b = len(pb) - sum(len(m[1]) - 1 for m in matched)
    short, long_ = min(eff_a, eff_b), max(eff_a, eff_b)
    score = (sum(m[2] for m in matched) / short) * (1 - 0.25 * (1 - short / long_))
    kinds = {m[3] for m in matched}
    for k, label in (("typo", "typo"), ("initial", "singkatan_inisial"), ("abbrev", "singkatan_kata"),
                     ("initials_multi", "inisial_beberapa_kata"), ("prefix", "nama_terpotong"), ("near", "kata_mirip_1_2_huruf")):
        if k in kinds:
            notes.append(label)
    if eff_a != eff_b or len(pa) != len(pb):
        notes.append("jumlah_kata_beda")
    if short == 1:
        score = min(score, 0.75)
        notes.append("satu_kata_saja")
    if matched and not (kinds - {"initial", "abbrev"}):
        score = min(score, 0.6)
    if "near" in kinds:
        score = min(score, 0.84)
    flags = []
    for ia, ib, sim, kind in matched:
        if kind != "exact" and len(ia) == 1 and len(ib) == 1:
            x, y = pa[ia[0]][1], pb[ib[0]][1]
            if _gender_flag(pa[ia[0]][0], pb[ib[0]][0]) or _gender_flag(x, y):
                flags.append("akhiran_gender_beda")
    ga, gb = {p for _, p in pa} & GENERATION, {p for _, p in pb} & GENERATION
    if ga != gb:
        flags.append("generasi_beda")
    da, db = {p for _, p in pa if p.isdigit()}, {p for _, p in pb if p.isdigit()}
    if da != db:
        flags.append("angka_beda")
    if flags:
        score = min(score, 0.60)
    js = [m[1][0] for m in sorted(matched, key=lambda m: m[0][0])]
    if js != sorted(js):
        score *= 0.97
        notes.append("urutan_beda")
    score = round(score, 3)
    tier = "DIFFERENT_HINT" if flags else ("VARIANT" if score >= NAME_OK else ("WEAK" if score >= NAME_WEAK else "DIFFERENT"))
    res.update(score=score, tier=tier, flags=sorted(set(flags)), notes=sorted(set(notes)))
    return res


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    print(json.dumps(name_similarity(sys.argv[1], sys.argv[2]), ensure_ascii=False, indent=2))
