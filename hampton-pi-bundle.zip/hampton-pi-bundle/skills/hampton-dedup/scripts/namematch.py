#!/usr/bin/env python3
"""Fuzzy name comparison for Indonesian person names. Stdlib only.

Usage:  python namematch.py "Dr. Ir. H. Budi Santoso, M.M." "BUDI SANTOSO"
Import: from namematch import name_similarity -> {"score": 0..1, "notes": [...], ...}
Thresholds: score >= NAME_OK -> nama dianggap sama; NAME_WEAK..NAME_OK -> mirip/perlu review.
"""
import json
import re
import sys
import unicodedata
from difflib import SequenceMatcher

NAME_OK = 0.85
NAME_WEAK = 0.70

# Gelar depan / sapaan (hanya dibuang di posisi awal)
PREFIX_TITLES = {
    "DR", "DRS", "DRA", "DRG", "IR", "PROF", "PROFESOR", "H", "HJ", "HAJI", "HAJJAH",
    "KH", "KYAI", "IBU", "BAPAK", "BPK", "NY", "NYONYA", "TN", "TUAN", "SDR", "SDRI",
    "MR", "MRS", "MS", "MISS", "DATO", "DATUK",
}
# Gelar belakang (hanya dibuang di posisi akhir)
DEGREES = {
    "SE", "SH", "SKOM", "SKOMP", "SSI", "ST", "SPD", "SPSI", "SIP", "SSOS", "SKM", "SKEP",
    "SPT", "SPI", "SHI", "SAG", "SSTP", "SPDI", "SFARM", "APT", "SPOG", "SPA", "SPPD", "SPJP",
    "SPB", "MM", "MBA", "MSI", "MSC", "MT", "MH", "MKOM", "MPD", "MPSI", "MAK", "MKES", "MKM",
    "MPH", "MARS", "MIM", "MSM", "PHD", "CPA", "CFA", "FRM", "CFP", "BSC", "BBA", "BCOM", "LLB",
    "LLM", "MSTAT", "AMD", "AMK", "AMA", "DIPL", "MA", "ME", "BA", "CA", "AK", "DRG",
}
AMBIGUOUS = {"MA", "ME", "BA", "CA", "AK"}  # baru dibuang kalau ada bukti tanda baca (titik/koma)
PARTICLES = {"BIN", "BINTI", "BT", "BTE", "BINTE", "BNT"}

# Ejaan lama/variasi -> bentuk kanonik (urutan penting)
SPELL = [("OE", "U"), ("DJ", "J"), ("TJ", "C"), ("SJ", "SY"), ("NJ", "NY"), ("DH", "D"),
         ("TH", "T"), ("PH", "F"), ("AA", "A"), ("EE", "E"), ("OO", "O"), ("UU", "U"),
         ("II", "I"), ("Y", "I")]
CANON = {
    "MOH": "MUHAMMAD", "MOHD": "MUHAMMAD", "MUH": "MUHAMMAD", "MHD": "MUHAMMAD",
    "MOHAMMAD": "MUHAMMAD", "MOHAMAD": "MUHAMMAD", "MUHAMAD": "MUHAMMAD",
    "MUHAMMED": "MUHAMMAD", "MOCHAMAD": "MUHAMMAD", "MOCHAMMAD": "MUHAMMAD",
    "MUCHAMMAD": "MUHAMMAD", "MUKHAMMAD": "MUHAMMAD", "MOHAMED": "MUHAMMAD",
    "ABD": "ABDUL",
}


def _spell(t):
    for a, b in SPELL:
        t = t.replace(a, b)
    return t


def _tokenize(raw):
    s = unicodedata.normalize("NFKD", str(raw or "")).encode("ascii", "ignore").decode().upper()
    s = s.replace("'", "").replace("`", "").replace("-", " ")
    toks = []  # (token, ada_bukti_tanda_baca)
    for pi, part in enumerate(s.split(",")):
        for w in part.split():
            letters = re.sub(r"[^A-Z0-9]", "", w)
            if not letters:
                continue
            evidence = pi > 0 or "." in w.strip(".")
            if (re.fullmatch(r"(?:[A-Z]\.){2,}[A-Z]?\.?", w)
                    and letters not in DEGREES and letters not in PREFIX_TITLES):
                toks.extend((c, False) for c in letters)  # A.R. -> A R
            else:
                toks.append((letters, evidence))
    return toks


def normalize_name(raw):
    """Return (tokens kanonik, notes)."""
    toks = _tokenize(raw)
    notes = []
    while len(toks) > 1 and toks[0][0] in PREFIX_TITLES:
        toks.pop(0)
        notes.append("gelar_depan_dibuang")
    while len(toks) > 1 and toks[-1][0] in DEGREES and (toks[-1][0] not in AMBIGUOUS or toks[-1][1]):
        toks.pop()
        notes.append("gelar_belakang_dibuang")
    out = []
    for t, _ in toks:
        if t in PARTICLES:
            continue
        t = _spell(t)
        out.append(CANON.get(t, t))
    return out, notes


def _token_sim(a, b):
    if a == b:
        return 1.0, "exact"
    if len(a) == 1 or len(b) == 1:
        return (0.9, "initial") if a[0] == b[0] else (0.0, "")
    short, long_ = (a, b) if len(a) <= len(b) else (b, a)
    if len(short) >= 3 and long_.startswith(short) and len(short) / len(long_) >= 0.5:
        return 0.88, "prefix"  # nama terpotong (field core banking sering dibatasi panjangnya)
    r = SequenceMatcher(None, a, b).ratio()
    return (r, "typo") if r >= 0.8 else (0.0, "")


def name_similarity(a, b):
    ta, na = normalize_name(a)
    tb, nb = normalize_name(b)
    res = {"score": 0.0, "a_norm": " ".join(ta), "b_norm": " ".join(tb), "notes": sorted(set(na + nb))}
    if not ta or not tb:
        res["notes"].append("nama_kosong")
        return res
    if ta == tb:
        res["score"] = 1.0
        return res
    if "".join(ta) == "".join(tb):
        res.update(score=0.95)
        res["notes"].append("spasi_beda")
        return res
    pairs = sorted(((*_token_sim(x, y), i, j) for i, x in enumerate(ta) for j, y in enumerate(tb)),
                   reverse=True)
    ui, uj, matched = set(), set(), []
    for sim, kind, i, j in pairs:
        if sim > 0 and i not in ui and j not in uj:
            ui.add(i)
            uj.add(j)
            matched.append((i, j, sim, kind))
    short, long_ = min(len(ta), len(tb)), max(len(ta), len(tb))
    score = (sum(m[2] for m in matched) / short) * (1 - 0.25 * (1 - short / long_))
    notes = res["notes"]
    kinds = {m[3] for m in matched}
    for k, label in (("typo", "typo"), ("initial", "singkatan_inisial"), ("prefix", "nama_terpotong")):
        if k in kinds:
            notes.append(label)
    if len(ta) != len(tb):
        notes.append("jumlah_kata_beda")
    if short == 1:
        score = min(score, 0.75)
        notes.append("satu_kata_saja")
    if matched and not (kinds - {"initial"}):
        score = min(score, 0.6)
    js = [m[1] for m in sorted(matched)]
    if js != sorted(js):
        score *= 0.97
        notes.append("urutan_beda")
    res["score"] = round(score, 3)
    res["notes"] = sorted(set(notes))
    return res


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    print(json.dumps(name_similarity(sys.argv[1], sys.argv[2]), ensure_ascii=False, indent=2))
