#!/usr/bin/env python3
"""Project Hampton - dedup nasabah HSBC vs nasabah existing OCBC. Stdlib only.

Usage:
  python dedup.py --hsbc hsbc.csv --ocbc ocbc.csv --map mapping.json --out result.csv

mapping.json: {"hsbc": {"rec_id":"CIF", "name":"NAMA", "dob":"TGL_LAHIR", "id_number":"NIK",
               "sid":"SID", "npwp":"NPWP", "mother_name":"IBU_KANDUNG", "phone":"HP", "email":"EMAIL"},
               "ocbc": {...}}   (field yang tidak ada boleh dihapus)
Output tidak memuat NIK/NPWP/SID mentah. Ringkasan di stdout hanya angka agregat.
"""
import argparse
import hashlib
import csv
import json
import os
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime

from namematch import NAME_OK, NAME_WEAK, name_similarity, normalize_name
from contactclean import clean_email, clean_phone
from policy import decide_status

RULE_VERSION = "2026.10-v3"  # v3: namematch v2 (tier, flag), policy.py, kolom untuk tahap LLM
MAX_BLOCK_SHARED = 20    # phone/email yang dipakai > N record = kemungkinan shared (keluarga/agen) -> abaikan
MAX_BLOCK_IDHALF = 500
DOB_FORMATS = ["%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y", "%Y%m%d", "%d%m%Y",
               "%d %b %Y", "%d %B %Y", "%Y/%m/%d"]
STATUS_RANK = {"MATCH": 4, "PROBABLE": 3, "REVIEW": 2, "NO_MATCH": 1}
ACTION = {"MATCH": "HOLD_EXISTING_CUSTOMER", "PROBABLE": "HOLD_EXISTING_CUSTOMER",
          "REVIEW": "HOLD_MANUAL_REVIEW", "NO_MATCH": "SEND_WELCOME_PACK"}  # saran; keputusan bisnis ada di owner


# ---------- normalisasi ----------
def norm_dob(s):
    s = (s or "").strip()
    if not s:
        return ""
    for cand in {s, s[:10], s.split("T")[0], s.split(" ")[0]}:
        for f in DOB_FORMATS:
            try:
                return datetime.strptime(cand, f).strftime("%Y-%m-%d")
            except ValueError:
                pass
    return "INVALID"


def norm_alnum(s):
    return re.sub(r"[^A-Z0-9]", "", (s or "").upper())


def norm_digits(s):
    return re.sub(r"\D", "", s or "")


def norm_phone(s):
    d = norm_digits(s)
    if d.startswith("620"):
        d = "62" + d[3:]
    if d.startswith("0"):
        d = "62" + d[1:]
    elif d.startswith("8"):
        d = "62" + d
    return d if len(d) >= 9 else ""


def nik_dob_ok(nik, dob):
    """NIK digit 7-12 = DDMMYY (hari +40 untuk perempuan). None kalau tidak bisa dicek."""
    if len(nik) != 16 or not nik.isdigit() or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", dob or ""):
        return None
    d, m, y = int(nik[6:8]), int(nik[8:10]), int(nik[10:12])
    d = d - 40 if d > 40 else d
    return d == int(dob[8:10]) and m == int(dob[5:7]) and y == int(dob[2:4])


def load(path, mapping):
    recs = []
    with open(path, newline="", encoding="utf-8-sig") as f:
        for n, r in enumerate(csv.DictReader(f), start=1):
            def g(k):
                return (r.get(mapping.get(k, ""), "") or "").strip()
            dob = norm_dob(g("dob"))
            rec = {"rec_id": g("rec_id") or str(n), "name": g("name"), "dob": "" if dob == "INVALID" else dob,
                   "id_number": norm_alnum(g("id_number")), "sid": norm_alnum(g("sid")),
                   "npwp": norm_digits(g("npwp")), "mother": g("mother_name"),
                   "phone": clean_phone(g("phone")), "email": clean_email(g("email")), "dq": []}
            if dob == "INVALID":
                rec["dq"].append("dob_invalid")
            if dob in ("1900-01-01", "1970-01-01"):
                rec["dq"].append("dob_placeholder")
            if not rec["name"]:
                rec["dq"].append("name_kosong")
            if not rec["id_number"]:
                rec["dq"].append("id_kosong")
            elif rec["id_number"].isdigit() and len(rec["id_number"]) != 16:
                rec["dq"].append("nik_bukan_16_digit")
            if nik_dob_ok(rec["id_number"], rec["dob"]) is False:
                rec["dq"].append("nik_vs_dob_tidak_cocok")
            toks, _ = normalize_name(rec["name"])
            rec["name_keys"] = {t[:3] for t in toks if len(t) >= 3}
            recs.append(rec)
    return recs


# ---------- blocking ----------
def block_keys(r):
    ks = []
    if r["id_number"]:
        ks.append(("id", r["id_number"]))
        if len(r["id_number"]) >= 12:  # salah 1 digit pasti ada 1 separuh yang sama
            h = len(r["id_number"]) // 2
            ks += [("ida", r["id_number"][:h]), ("idb", r["id_number"][h:])]
    for f in ("sid", "npwp", "phone", "email"):
        if r[f]:
            ks.append((f, r[f]))
    if r["dob"]:
        ks.append(("dob", r["dob"]))
    return ks


def candidates(h, idx, ocbc):
    out = set()
    for k in block_keys(h):
        lst = idx.get(k, [])
        kind = k[0]
        if kind in ("phone", "email") and len(lst) > MAX_BLOCK_SHARED:
            continue
        if kind in ("ida", "idb") and len(lst) > MAX_BLOCK_IDHALF:
            continue
        if kind == "dob":  # blok besar -> saring cepat pakai kemiripan awal nama
            out.update(i for i in lst if h["name_keys"] & ocbc[i]["name_keys"])
        else:
            out.update(lst)
    return out


# ---------- scoring ----------
def id_near(a, b):
    if not a or not b or a == b or len(a) != len(b):
        return False
    d = [i for i in range(len(a)) if a[i] != b[i]]
    return len(d) == 1 or (len(d) == 2 and d[1] == d[0] + 1 and a[d[0]] == b[d[1]] and a[d[1]] == b[d[0]])


def dob_near(a, b):
    if not a or not b or a == b:
        return False
    ya, ma, da = a.split("-")
    yb, mb, db = b.split("-")
    if ya == yb and ma == db and mb == da:
        return True  # hari-bulan tertukar
    return sum([ya != yb, ma != mb, da != db]) == 1


def pair_key(a_norm, b_norm):
    return hashlib.sha1("|".join(sorted([a_norm, b_norm])).encode()).hexdigest()[:12]


def evaluate(h, o):
    ns = name_similarity(h["name"], o["name"])
    name_ok, name_weak = ns["score"] >= NAME_OK, NAME_WEAK <= ns["score"] < NAME_OK
    dob_ok = bool(h["dob"]) and h["dob"] == o["dob"]
    id_ok = bool(h["id_number"]) and h["id_number"] == o["id_number"]
    n_id, n_dob = id_near(h["id_number"], o["id_number"]), dob_near(h["dob"], o["dob"])
    id_conflict = bool(h["id_number"] and o["id_number"]) and not id_ok and not n_id
    sec = {"sid": bool(h["sid"]) and h["sid"] == o["sid"], "npwp": bool(h["npwp"]) and h["npwp"] == o["npwp"]}
    ter = {"mother": bool(h["mother"] and o["mother"]) and name_similarity(h["mother"], o["mother"])["score"] >= NAME_OK,
           "phone": bool(h["phone"]) and h["phone"] == o["phone"],
           "email": bool(h["email"]) and h["email"] == o["email"]}
    reasons = list(ns["notes"]) + ["nama_" + f for f in ns["flags"]]
    if n_id:
        reasons.append("id_beda_1_digit_atau_tertukar")
    if n_dob:
        reasons.append("dob_near_(tukar_hari_bulan_atau_1_komponen)")
    status, why = decide_status(name_ok, name_weak, dob_ok, id_ok, n_id, n_dob, id_conflict, sum(sec.values()),
                                sum(ter.values()), name_hint=bool(ns["flags"]))
    p = int(name_ok) + int(dob_ok) + int(id_ok)
    return {"status": status, "p": p, "support": 2 * sum(sec.values()) + sum(ter.values()), "name_score": ns["score"],
            "name_ok": name_ok, "dob_ok": dob_ok, "id_ok": id_ok, **{k + "_ok": v for k, v in {**sec, **ter}.items()},
            "name_tier": ns["tier"], "name_flags": ";".join(ns["flags"]), "id_near": n_id, "dob_near": n_dob,
            "id_conflict": id_conflict, "pair_key": pair_key(ns["a_norm"], ns["b_norm"]), "name_notes": ";".join(ns["notes"]),
            "reasons": ";".join(sorted(set(reasons + why)))}


def best_for(h, idx, ocbc):
    best, n = None, 0
    for i in candidates(h, idx, ocbc):
        ev = evaluate(h, ocbc[i])
        if ev["status"] == "NO_MATCH":
            continue
        n += 1
        key = (STATUS_RANK[ev["status"]], ev["p"], ev["support"], ev["name_score"])
        if best is None or key > best[0]:
            best = (key, i, ev)
    return best, n


COLS = ["hsbc_rec_id", "status", "suggested_action", "ocbc_rec_id", "n_candidates", "name_score", "name_ok",
        "dob_ok", "id_ok", "sid_ok", "npwp_ok", "mother_ok", "phone_ok", "email_ok", "reasons",
        "hsbc_dq_flags", "hsbc_name", "ocbc_name", "rule_version",
        "name_tier", "name_flags", "id_near", "dob_near", "id_conflict", "pair_key",
        "status_rule", "llm_verdict", "name_ok_llm", "decision_basis"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--hsbc", required=True)
    ap.add_argument("--ocbc", required=True)
    ap.add_argument("--map", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--judge-queue", help="tulis antrean pasangan nama untuk hampton-name-judge (hanya nama, tanpa DOB/ID)")
    ap.add_argument("--judge-cache", help="CSV cache penilaian sebelumnya; pasangan yang sudah ada tidak masuk antrean")
    a = ap.parse_args()
    mp = json.load(open(a.map, encoding="utf-8"))
    hsbc, ocbc = load(a.hsbc, mp["hsbc"]), load(a.ocbc, mp["ocbc"])
    idx = defaultdict(list)
    for i, r in enumerate(ocbc):
        for k in block_keys(r):
            idx[k].append(i)
    cnt, dq = Counter(), Counter()
    queue = {}
    cached = set()
    if a.judge_cache and os.path.exists(a.judge_cache):
        cached = {r["pair_key"] for r in csv.DictReader(open(a.judge_cache, newline="", encoding="utf-8-sig"))}
    with open(a.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=COLS)
        w.writeheader()
        for h in hsbc:
            best, n = best_for(h, idx, ocbc)
            row = {c: "" for c in COLS}
            row.update(hsbc_rec_id=h["rec_id"], n_candidates=n, hsbc_dq_flags=";".join(h["dq"]),
                       rule_version=RULE_VERSION)
            if best:
                _, i, ev = best
                row.update(status=ev["status"], ocbc_rec_id=ocbc[i]["rec_id"], name_score=ev["name_score"],
                           reasons=ev["reasons"], hsbc_name=h["name"], ocbc_name=ocbc[i]["name"],
                           **{k: ev[k] for k in ("name_ok", "dob_ok", "id_ok", "sid_ok", "npwp_ok", "mother_ok", "phone_ok",
                                                  "email_ok", "name_tier", "name_flags", "id_near", "dob_near", "id_conflict",
                                                  "pair_key")})
                if (not ev["name_ok"] and ev["name_tier"] != "DIFFERENT_HINT"
                        and (ev["dob_ok"] or ev["id_ok"] or ev["id_near"] or ev["dob_near"])
                        and ev["pair_key"] not in cached and ev["pair_key"] not in queue):
                    queue[ev["pair_key"]] = {"pair_key": ev["pair_key"], "name_a": h["name"], "name_b": ocbc[i]["name"],
                                             "rule_score": ev["name_score"], "rule_tier": ev["name_tier"], "rule_notes": ev["name_notes"]}
            else:
                row["status"] = "NO_MATCH"
            row["suggested_action"] = ACTION[row["status"]]
            row["status_rule"], row["decision_basis"] = row["status"], "RULE"
            cnt[row["status"]] += 1
            dq.update(h["dq"])
            w.writerow(row)
    if a.judge_queue:
        with open(a.judge_queue, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=["pair_key", "name_a", "name_b", "rule_score", "rule_tier", "rule_notes"])
            w.writeheader()
            w.writerows(queue.values())
    print(json.dumps({"hsbc_rows": len(hsbc), "ocbc_rows": len(ocbc), "status": dict(cnt),
                      "hsbc_dq_flags": dict(dq), "rule_version": RULE_VERSION,
                      "judge_queue_pairs": len(queue) if a.judge_queue else None}, indent=2))


if __name__ == "__main__":
    main()
