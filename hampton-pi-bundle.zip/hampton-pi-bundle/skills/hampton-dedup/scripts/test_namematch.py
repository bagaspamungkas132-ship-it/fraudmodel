#!/usr/bin/env python3
"""Regression tests nama. Jalankan: python test_namematch.py  (tambah kasus nyata yang pernah salah)."""
from namematch import name_similarity, NAME_OK

SAME = [  # harus >= NAME_OK
    ("Dr. Ir. H. Budi Santoso, M.M.", "BUDI SANTOSO"),
    ("BUDI SANTOSO SE", "Budi Santoso"),
    ("Santoso Budi", "Budi Santoso"),
    ("Moh. Rizky Pratama", "Muhammad Rizki Pratama"),
    ("M. Rizki Pratama", "Muhammad Rizki Pratama"),
    ("Soeharto", "Suharto"),
    ("Siti Aminah Binti Abdullah", "Siti Aminah"),
    ("Budi Santosa", "Budi Santoso"),
    ("Surya Darma", "Suryadarma"),
    ("Budi Santo", "Budi Santoso"),
    ("A.R. Rahman Hakim", "Abdul Rahman Hakim"),
]
SAME += [  # pola v2: terpotong, singkatan, inisial beberapa kata, spasi, ejaan
    ("BUDI TRESNA UT", "BUDI TRESNA UTAMA"),
    ("AGUS SETIAWAN HIDAYAT", "AGUSTIAWAN HIDAYAT"),
    ("SITI WIDYA CH K", "SITI WIDYA CHRISTIANA KESUMA"),
    ("DEWI ANGELA HM", "DEWI ANGELA HENRIKA MAUREN"),
    ("RINA ARIESTA AW", "RINA ARIESTA ADIWINATA"),
    ("IDA BAGUS NGR PRAMANA", "IDA BAGUS NGURAH PRAMANA"),
    ("SARI MAHESA ADISOEJOSO", "SARI MAHESA ADISO"),
    ("TONO PUJI ASTUTI", "TONO PUJIASTUSI"),
    ("ANDI NATALIJA KUSUMA PUTERI", "ANDI NATALIA KUSUMAPUTRI"),
    ("RIA SANTOSOJOESE", "RIA SANTOSO JOE"),
]
WEAK = [  # zona abu-abu: 0.70 <= skor < 0.85 -> serahkan ke LLM bila DOB/ID cocok
    ("RIZKI IMAM P SUTAN", "RIZKI IMAN P SUTAN"),
    ("DEVI PERMATA SARI NASUTION", "DESI PERMATA SARI NASUTION"),
    ("DWI ROHMAH YUNI ASTUTI", "DWI ROHMAH ZUNI ASTUTI"),
    ("M ZAKI ARI ANWAR", "M ZAKI ABI ANWAR"),
]
HINT = [  # flag negatif tegas: tier DIFFERENT_HINT, skor <= 0.60
    ("DEDI KURNIAWAN", "DEDI KURNIAWATI"),
    ("BUDI SANTOSO JR", "BUDI SANTOSO SR"),
    ("AGUS SETIAWAN", "AGUSTINA SETIAWAN"),
]
DIFF = [  # harus < NAME_OK
    ("Budi Santoso", "Budi Wijaya"),
    ("Ahmad Fauzi", "Ahmad Fauzan"),
    ("Muhammad Rizki", "Maria Rizki Putri"),
    ("Budi", "Budi Santoso Wijaya"),
]
bad = 0
for a, b in SAME:
    s = name_similarity(a, b)["score"]
    if s < NAME_OK:
        bad += 1
        print(f"FAIL same  {s:.3f}  {a!r} vs {b!r}")
for a, b in DIFF:
    s = name_similarity(a, b)["score"]
    if s >= NAME_OK:
        bad += 1
        print(f"FAIL diff  {s:.3f}  {a!r} vs {b!r}")
from namematch import NAME_WEAK
for a, b in WEAK:
    r = name_similarity(a, b)
    if not (NAME_WEAK <= r["score"] < NAME_OK) or r["tier"] != "WEAK":
        bad += 1
        print(f"FAIL weak  {r['score']:.3f} {r['tier']}  {a!r} vs {b!r}")
for a, b in HINT:
    r = name_similarity(a, b)
    if r["tier"] != "DIFFERENT_HINT" or r["score"] > 0.60 or not r["flags"]:
        bad += 1
        print(f"FAIL hint  {r['score']:.3f} {r['tier']}  {a!r} vs {b!r}")
print("OK" if not bad else f"{bad} gagal")
raise SystemExit(1 if bad else 0)
