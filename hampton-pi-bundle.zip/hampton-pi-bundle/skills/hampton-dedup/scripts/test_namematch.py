#!/usr/bin/env python3
"""Regression tests nama. Jalankan: python test_namematch.py  (tambah kasus nyata yang pernah salah)."""
from namematch import name_similarity, NAME_OK

SAME = [  # harus >= NAME_OK
    ("Dr. Ir. H. Budi Santoso, M.M.", "BUDI SANTOSO"),
    ("BUDI SANTOSO SE", "Budi Santoso"),
    ("Santoso Budi", "Budi Santoso"),
    ("Moh. Rizky Pratama", "Muhammad Rizki Pratama"),
    ("M. Rizki Pratama", "Muhammad Rizki Pratama"),
    ("Soeharto", "Suharto"),
    ("Siti Aminah Binti Abdullah", "Siti Aminah"),
    ("Budi Santosa", "Budi Santoso"),
    ("Surya Darma", "Suryadarma"),
    ("Budi Santo", "Budi Santoso"),
    ("A.R. Rahman Hakim", "Abdul Rahman Hakim"),
]
DIFF = [  # harus < NAME_OK
    ("Budi Santoso", "Budi Wijaya"),
    ("Ahmad Fauzi", "Ahmad Fauzan"),
    ("Muhammad Rizki", "Maria Rizki Putri"),
    ("Budi", "Budi Santoso Wijaya"),
]
bad = 0
for a, b in SAME:
    s = name_similarity(a, b)["score"]
    if s < NAME_OK:
        bad += 1
        print(f"FAIL same  {s:.3f}  {a!r} vs {b!r}")
for a, b in DIFF:
    s = name_similarity(a, b)["score"]
    if s >= NAME_OK:
        bad += 1
        print(f"FAIL diff  {s:.3f}  {a!r} vs {b!r}")
print("OK" if not bad else f"{bad} gagal")
raise SystemExit(1 if bad else 0)
