#!/usr/bin/env python3
"""Bandingkan penilaian ulang buta checker dengan penilaian judge, lalu tambahkan C13 ke check_report.json.

Usage: python compare_resample.py --key checks/llm_resample_key.csv --resample checks/llm_resample_results.csv --report checks/check_report.json
FAIL bila ada kontradiksi SAME vs DIFFERENT; WARN bila kesepakatan < 90%.
"""
import argparse, csv, json, sys

ap = argparse.ArgumentParser()
ap.add_argument("--key", required=True); ap.add_argument("--resample", required=True); ap.add_argument("--report", required=True)
a = ap.parse_args()
key = {r["pair_key"]: r["judge_verdict"].upper() for r in csv.DictReader(open(a.key, newline="", encoding="utf-8-sig"))}
res = {r["pair_key"]: r["verdict"].strip().upper() for r in csv.DictReader(open(a.resample, newline="", encoding="utf-8-sig"))}
common = [k for k in key if k in res]
agree = [k for k in common if key[k] == res[k]]
contra = [k for k in common if {key[k], res[k]} == {"SAME", "DIFFERENT"}]
rate = len(agree) / len(common) if common else 0.0
status = "FAIL" if contra or not common else ("WARN" if rate < 0.9 else "PASS")
rep = json.load(open(a.report, encoding="utf-8"))
rep["checks"] = [c for c in rep["checks"] if not c["id"].startswith("C13")]
rep["checks"].append({"id": "C13_penilaian_ulang_buta_llm", "status": status, "n_violations": len(contra), "violations": contra[:25],
                      "detail": f"sampel={len(common)} sepakat={len(agree)} ({rate:.0%}) kontradiksi_SAME_vs_DIFFERENT={len(contra)} belum_dinilai_ulang={len(set(key) - set(res))}"})
rep["overall"] = "FAIL" if any(c["status"] == "FAIL" for c in rep["checks"]) else ("PASS_WITH_WARNINGS" if any(c["status"] == "WARN" for c in rep["checks"]) else "PASS")
json.dump(rep, open(a.report, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(json.dumps({"overall": rep["overall"], "C13": rep["checks"][-1]["detail"], "status": status}, ensure_ascii=False, indent=1))
sys.exit(1 if rep["overall"] == "FAIL" else 0)
