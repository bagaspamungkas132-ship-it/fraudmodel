#!/usr/bin/env python3
"""Gabungkan penilaian nama LLM ke hasil dedup lewat policy.py. Stdlib only.

Usage:
  python apply_name_judgments.py --result result.csv --judgments name_judge_results.csv [more.csv ...] --out result_final.csv \
      [--cache name_judge_cache.csv]

Aturan: LLM hanya mengisi penilaian NAMA. SAME -> name_ok; DIFFERENT -> penanda beda tegas; UNSURE -> status tidak berubah.
Status akhir tetap diturunkan policy.decide_status. LLM tidak bisa membuat MATCH bila DOB atau ID tidak cocok persis.
Kolom yang ditambah/diubah: llm_verdict, name_ok_llm, status (final), status_rule (asli), decision_basis, suggested_action, reasons.
"""
import argparse
import csv
import json
import os
from collections import Counter
from datetime import datetime, timezone

from dedup import ACTION
from policy import decide_status

VALID = {"SAME", "DIFFERENT", "UNSURE"}
T = lambda v: str(v).strip() == "True"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--result", required=True)
    ap.add_argument("--judgments", nargs="+", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--cache")
    a = ap.parse_args()
    J, invalid, dup = {}, 0, 0
    for p in a.judgments:
        for r in csv.DictReader(open(p, newline="", encoding="utf-8-sig")):
            k = r["pair_key"].strip()
            v = r["verdict"].strip().upper()
            if v not in VALID:
                invalid += 1
                v = "UNSURE"
            if k in J:
                dup += 1
            J[k] = {**r, "verdict": v}
    rows = list(csv.DictReader(open(a.result, newline="", encoding="utf-8-sig")))
    cols = list(rows[0].keys()) if rows else []
    applied, trans, vc = 0, Counter(), Counter()
    for r in rows:
        k = r.get("pair_key", "")
        if r["status"] == "NO_MATCH" or T(r["name_ok"]) or not k or k not in J:
            continue
        j = J[k]
        v = j["verdict"]
        applied += 1
        vc[v] += 1
        r["llm_verdict"] = v
        r["decision_basis"] = "RULE+LLM"
        extra = [f"LLM:{v}:{j.get('case_type', '')}".rstrip(":")]
        if v != "UNSURE":
            name_ok = v == "SAME"
            new, why = decide_status(name_ok, False, T(r["dob_ok"]), T(r["id_ok"]), T(r["id_near"]), T(r["dob_near"]),
                                     T(r["id_conflict"]), T(r["sid_ok"]) + T(r["npwp_ok"]),
                                     T(r["mother_ok"]) + T(r["phone_ok"]) + T(r["email_ok"]), name_hint=(v == "DIFFERENT"))
            r["name_ok_llm"] = str(name_ok)
            extra += why
            if new != r["status"]:
                trans[f"{r['status']}->{new}"] += 1
            r["status"] = new
            r["suggested_action"] = ACTION[new]
        r["reasons"] = ";".join(x for x in (r["reasons"], *extra) if x)
    with open(a.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)
    if a.cache:
        have = set()
        if os.path.exists(a.cache):
            have = {r["pair_key"] for r in csv.DictReader(open(a.cache, newline="", encoding="utf-8-sig"))}
        new_rows = [{"pair_key": k, "verdict": j["verdict"], "case_type": j.get("case_type", ""), "confidence": j.get("confidence", ""),
                     "reason": j.get("reason", ""), "judged_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                     "prompt_version": j.get("prompt_version", "")} for k, j in J.items() if k not in have]
        exists = os.path.exists(a.cache)
        with open(a.cache, "a", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=["pair_key", "verdict", "case_type", "confidence", "reason", "judged_at", "prompt_version"])
            if not exists:
                w.writeheader()
            w.writerows(new_rows)
    print(json.dumps({"rows": len(rows), "llm_applied_rows": applied, "verdicts": dict(vc), "status_changes": dict(trans),
                      "invalid_verdicts_as_UNSURE": invalid, "duplicate_pair_keys": dup}, indent=1))


if __name__ == "__main__":
    main()
