#!/usr/bin/env python3
"""Jejak audit satu run dedup (peran: AUDITOR, deterministik, tanpa AI). Stdlib only. Tanpa data pribadi: hanya hash, hitungan, versi.

Usage:
  python audit_run.py --hsbc hsbc.csv --ocbc ocbc.csv --map mapping.json --result result.csv \
      --check-report checks/check_report.json --out-dir audit/ [--prev-result prev_result.csv] [--note "catatan"]
"""
import argparse, csv, getpass, hashlib, json, os, platform
from collections import Counter
from datetime import datetime, timezone

import dedup
import namematch


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def nrows(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        return sum(1 for _ in csv.DictReader(f))


def main():
    ap = argparse.ArgumentParser()
    for k in ("hsbc", "ocbc", "map", "result", "out_dir"):
        ap.add_argument("--" + k.replace("_", "-"), required=True)
    ap.add_argument("--check-report"); ap.add_argument("--prev-result"); ap.add_argument("--note", default="")
    ap.add_argument("--judgments", nargs="*", default=[], help="file penilaian judge (untuk hash dan versi prompt)")
    a = ap.parse_args()
    os.makedirs(a.out_dir, exist_ok=True)
    res = list(csv.DictReader(open(a.result, newline="", encoding="utf-8-sig")))
    rep = json.load(open(a.check_report, encoding="utf-8")) if a.check_report else None
    audit = {
        "waktu_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"), "dijalankan_oleh": getpass.getuser(),
        "python": platform.python_version(), "rule_version": sorted({r["rule_version"] for r in res}),
        "parameter": {"NAME_OK": namematch.NAME_OK, "NAME_WEAK": namematch.NAME_WEAK, "MAX_BLOCK_SHARED": dedup.MAX_BLOCK_SHARED,
                      "MAX_BLOCK_IDHALF": dedup.MAX_BLOCK_IDHALF},
        "input": {n: {"file": os.path.basename(p), "sha256": sha(p), "baris": nrows(p)} for n, p in (("hsbc", a.hsbc), ("ocbc", a.ocbc))},
        "mapping": {"file": os.path.basename(a.map), "sha256": sha(a.map)},
        "hasil": {"file": os.path.basename(a.result), "sha256": sha(a.result), "baris": len(res)},
        "rekonsiliasi": {"hsbc_masuk": nrows(a.hsbc), "hasil_keluar": len(res), "sama": nrows(a.hsbc) == len(res)},
        "status": dict(Counter(r["status"] for r in res)), "suggested_action": dict(Counter(r["suggested_action"] for r in res)),
        "verdict_checker": rep["overall"] if rep else "BELUM_DICEK", "catatan": a.note,
        "llm": {"baris_keputusan_rule": sum(1 for r in res if r.get("decision_basis", "RULE") == "RULE"),
                "baris_keputusan_rule_plus_llm": sum(1 for r in res if str(r.get("decision_basis", "")).startswith("RULE+LLM")),
                "verdict": dict(Counter(r["llm_verdict"] for r in res if r.get("llm_verdict"))),
                "file_penilaian": [{"file": os.path.basename(p), "sha256": sha(p), "baris": nrows(p),
                                    "prompt_version": sorted({r.get("prompt_version", "") for r in csv.DictReader(open(p, newline="", encoding="utf-8-sig"))})}
                                   for p in a.judgments]},
    }
    if a.prev_result:
        prev = {r["hsbc_rec_id"]: r["status"] for r in csv.DictReader(open(a.prev_result, newline="", encoding="utf-8-sig"))}
        tr = Counter((prev[r["hsbc_rec_id"]], r["status"]) for r in res if r["hsbc_rec_id"] in prev and prev[r["hsbc_rec_id"]] != r["status"])
        audit["perubahan_vs_run_sebelumnya"] = {f"{o}->{n}": c for (o, n), c in tr.items()}
        audit["baru_dibanding_sebelumnya"] = len({r["hsbc_rec_id"] for r in res} - set(prev))
    base = os.path.join(a.out_dir, "audit_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ"))
    json.dump(audit, open(base + ".json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    md = ["# Audit run Hampton dedup", "", f"- Waktu (UTC): {audit['waktu_utc']}  | oleh: {audit['dijalankan_oleh']}",
          f"- rule_version: {', '.join(audit['rule_version'])}  | NAME_OK={namematch.NAME_OK}, NAME_WEAK={namematch.NAME_WEAK}",
          f"- Rekonsiliasi: HSBC masuk {audit['rekonsiliasi']['hsbc_masuk']} = hasil keluar {audit['rekonsiliasi']['hasil_keluar']} -> {'OK' if audit['rekonsiliasi']['sama'] else 'TIDAK SAMA'}",
          f"- Status: {audit['status']}", f"- Verdict checker: {audit['verdict_checker']}",
          f"- Keputusan: rule saja {audit['llm']['baris_keputusan_rule']} baris; rule+LLM {audit['llm']['baris_keputusan_rule_plus_llm']} baris; verdict LLM {audit['llm']['verdict']}", ""]
    for n in ("hsbc", "ocbc"):
        i = audit["input"][n]; md.append(f"- Input {n}: {i['file']} ({i['baris']} baris) sha256 {i['sha256'][:16]}...")
    md.append(f"- Hasil: {audit['hasil']['file']} sha256 {audit['hasil']['sha256'][:16]}...")
    for jf in audit["llm"]["file_penilaian"]:
        md.append(f"- Penilaian judge: {jf['file']} ({jf['baris']} pasangan) prompt {jf['prompt_version']} sha256 {jf['sha256'][:16]}...")
    if "perubahan_vs_run_sebelumnya" in audit:
        md.append(f"- Perubahan vs run sebelumnya: {audit['perubahan_vs_run_sebelumnya']} (baru: {audit['baru_dibanding_sebelumnya']})")
    if a.note:
        md.append(f"- Catatan: {a.note}")
    md += ["", "Persetujuan manusia sebelum welcome pack dikirim: [ ] disetujui oleh ______ tanggal ______"]
    open(base + ".md", "w", encoding="utf-8").write("\n".join(md) + "\n")
    print(json.dumps({"audit_file": os.path.basename(base) + ".json", "rekonsiliasi_ok": audit["rekonsiliasi"]["sama"],
                      "verdict_checker": audit["verdict_checker"], "status": audit["status"]}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
