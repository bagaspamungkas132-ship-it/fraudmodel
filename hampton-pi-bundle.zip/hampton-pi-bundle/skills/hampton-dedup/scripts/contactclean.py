#!/usr/bin/env python3
"""contactclean.py - SALINAN blok HP + email dari skill hampton-validate-contact.

Dipakai dedup.py agar skill ini berdiri sendiri. HP/email dummy atau tidak valid dikembalikan
kosong supaya tidak dihitung sebagai penguat match. Jika aturan HP/email diubah di
hampton-validate-contact/scripts/validate_contact.py, sinkronkan blok ini.
"""
import re

# =============================== PHONE ===============================
MOBILE_RE = re.compile(r"^628[1235789]\d+$")


def _phone_one(raw):
    notes = []
    s = raw.strip()
    digits = re.sub(r"\D", "", s)
    if not digits:
        return {"norm": "", "type": "", "valid": "NO", "notes": ["hp_bukan_angka"]}
    if s.startswith("+") and not s.startswith("+62"):
        return {"norm": digits, "type": "foreign", "valid": "CHECK", "notes": ["hp_luar_negeri"]}
    if digits.startswith("00"):
        digits = digits[2:]
    if digits.startswith("62"):
        national = digits[2:].lstrip("0") if digits[2:3] == "0" else digits[2:]
    elif digits.startswith("0"):
        national = digits[1:]
    elif digits.startswith("8"):
        national = digits
    else:
        return {"norm": digits, "type": "", "valid": "NO", "notes": ["hp_format_tidak_dikenal"]}
    norm = "62" + national
    ptype = "mobile" if national.startswith("8") else "landline"
    valid = "YES"
    steps = sum(int(y) - int(x) == 1 for x, y in zip(national, national[1:]))
    steps_down = sum(int(x) - int(y) == 1 for x, y in zip(national, national[1:]))
    if len(set(national)) <= 2 or re.search(r"(\d)\1{6,}", national) or max(steps, steps_down) >= len(national) - 2:
        return {"norm": norm, "type": ptype, "valid": "NO", "notes": ["hp_dummy_atau_berulang"]}
    if ptype == "mobile":
        if not MOBILE_RE.match(norm):
            valid = "NO"
            notes.append("hp_prefix_operator_tidak_dikenal")
        if len(norm) < 11:
            valid = "NO"
            notes.append("hp_terlalu_pendek")
        elif len(norm) > 14:
            valid = "NO"
            notes.append("hp_terlalu_panjang")
    else:
        if not 10 <= len(norm) <= 13:
            valid = "NO"
            notes.append("telepon_rumah_panjang_tidak_wajar")
        else:
            notes.append("telepon_rumah_bukan_hp")
            valid = "CHECK"
    return {"norm": norm, "type": ptype, "valid": valid, "notes": notes}


def phone_info(raw):
    raw = (raw or "").strip()
    if not raw or raw.upper() in {"-", "N/A", "NA", "NULL", "TIDAK ADA", "TDK ADA"}:
        return {"norm": "", "type": "", "valid": "NO", "notes": ["hp_kosong"]}
    parts = [p for p in re.split(r"[,;/]|\bATAU\b|\bDAN\b", raw, flags=re.I) if re.search(r"\d", p)]
    infos = [_phone_one(p) for p in parts] or [_phone_one(raw)]
    best = next((i for i in infos if i["valid"] == "YES"), infos[0])
    if len(infos) > 1:
        best = {**best, "notes": best["notes"] + ["hp_lebih_dari_1_nomor"]}
    return best


def clean_phone(raw):
    """Untuk dedup: nomor ternormalisasi hanya bila valid; selain itu '' (jangan jadi sinyal match)."""
    i = phone_info(raw)
    return i["norm"] if i["valid"] == "YES" else ""


# =============================== EMAIL ===============================
EMAIL_RE = re.compile(r"^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@(?:[a-z0-9-]+\.)+[a-z]{2,}$")
DOMAIN_FIX = {
    "gmial.com": "gmail.com", "gmai.com": "gmail.com", "gmail.co": "gmail.com", "gmail.con": "gmail.com",
    "gamil.com": "gmail.com", "gmail.cm": "gmail.com", "gnail.com": "gmail.com", "gmail.om": "gmail.com",
    "yaho.com": "yahoo.com", "yahooo.com": "yahoo.com", "yahoo.con": "yahoo.com",
    "yahoo.co.od": "yahoo.co.id", "yahoo.coid": "yahoo.co.id", "yahoo.co.i": "yahoo.co.id",
    "hotmal.com": "hotmail.com", "hotmail.con": "hotmail.com", "outlok.com": "outlook.com",
    "outlook.con": "outlook.com", "icloud.con": "icloud.com",
}
DISPOSABLE = {"mailinator.com", "guerrillamail.com", "10minutemail.com", "tempmail.com", "yopmail.com",
              "trashmail.com", "sharklasers.com", "throwawaymail.com"}
PLACEHOLDER_LOCAL = {"test", "tes", "noemail", "none", "tidakada", "tdkada", "xxx", "xx", "abc", "aaa",
                     "email", "na", "nomail", "no.email", "belumpunya", "tidakpunya"}
PLACEHOLDER_DOMAIN = {"test.com", "example.com", "noemail.com", "xxx.com", "email.com", "tidakada.com"}


def email_info(raw):
    raw = (raw or "").strip().lower()
    if not raw or raw in {"-", "n/a", "na", "null", "tidak ada", "tdk ada"}:
        return {"norm": "", "valid": "NO", "notes": ["email_kosong"], "suggestion": ""}
    cands = [c for c in re.split(r"[,;\s]+", raw) if "@" in c] or [raw]
    notes = ["email_lebih_dari_1"] if len(cands) > 1 else []
    e = cands[0].strip(".<>()\"'")
    if not EMAIL_RE.match(e) or ".." in e or e.split("@")[0].startswith(".") or e.split("@")[0].endswith(".") \
            or len(e.split("@")[0]) > 64:
        return {"norm": e, "valid": "NO", "notes": notes + ["email_format_salah"], "suggestion": ""}
    local, dom = e.split("@")
    if local in PLACEHOLDER_LOCAL or dom in PLACEHOLDER_DOMAIN:
        return {"norm": e, "valid": "NO", "notes": notes + ["email_placeholder"], "suggestion": ""}
    if dom in DOMAIN_FIX:
        return {"norm": e, "valid": "CHECK", "notes": notes + ["email_domain_diduga_typo"],
                "suggestion": f"{local}@{DOMAIN_FIX[dom]}"}
    if dom in DISPOSABLE:
        return {"norm": e, "valid": "CHECK", "notes": notes + ["email_sekali_pakai"], "suggestion": ""}
    return {"norm": e, "valid": "YES", "notes": notes, "suggestion": ""}


def clean_email(raw):
    i = email_info(raw)
    return i["norm"] if i["valid"] == "YES" else ""


