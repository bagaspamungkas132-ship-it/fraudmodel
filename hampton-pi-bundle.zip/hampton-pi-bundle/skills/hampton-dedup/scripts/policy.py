#!/usr/bin/env python3
"""Kebijakan status dedup (satu-satunya tempat aturan status). Dipakai dedup.py (tahap rule) dan apply_name_judgments.py (tahap LLM).

Aturan dari user: 3 primary (Nama, DOB, ID) cocok = MATCH. LLM hanya boleh mengubah penilaian NAMA (name_ok / name_hint);
LLM tidak pernah bisa menghasilkan MATCH bila DOB atau ID tidak cocok persis.
"""


def decide_status(name_ok, name_weak, dob_ok, id_ok, id_near, dob_near, id_conflict, n_sec, n_ter, name_hint=False):
    name_ok, name_weak, dob_ok, id_ok = bool(name_ok), bool(name_weak), bool(dob_ok), bool(id_ok)
    p = int(name_ok) + int(dob_ok) + int(id_ok)
    support = 2 * n_sec + n_ter
    near_third = (not name_ok and name_weak) or (not id_ok and id_near) or (not dob_ok and dob_near)
    reasons = []
    if p == 3:
        status = "MATCH"
    elif id_conflict and name_ok and dob_ok:
        status = "REVIEW"
        reasons.append("nama+dob sama tapi ID beda: kemungkinan kembar/salah input ID")
    elif p == 2:
        if not name_ok and name_hint:
            status = "REVIEW"
            reasons.append("DOB dan ID cocok tapi nama berbeda tegas: kemungkinan salah data/ganti nama")
        else:
            need = 1 if near_third else 2
            status = "PROBABLE" if support >= need else "REVIEW"
    elif p == 1 and support >= 2:
        status = "REVIEW"
    elif id_ok and (name_weak or dob_near or support >= 1):
        status = "REVIEW"
    elif p == 0 and n_sec == 2:
        status = "REVIEW"
    else:
        status = "NO_MATCH"
    return status, reasons
