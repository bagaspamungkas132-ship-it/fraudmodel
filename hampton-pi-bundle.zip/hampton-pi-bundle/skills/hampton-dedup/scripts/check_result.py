#!/usr/bin/env python3
"""Checker deterministik untuk hasil dedup.py (peran: CHECKER, independen dari maker). Stdlib only.

Usage:
  python check_result.py --result result.csv --hsbc hsbc.csv --map mapping.json --out-dir checks/ [--sample 40 --seed 7]

Menulis ke --out-dir:
  check_report.json   verdict PASS/FAIL + hasil tiap pemeriksaan (tanpa data pribadi; hanya rec_id)
  qa_sample.csv       sampel acak per status untuk dicek manual/AI (nama saja, tanpa ID/DOB/HP/email)
  grey_names.csv      pasangan nama zona abu-abu untuk dinilai AI (nama saja)
Exit code 1 bila ada pemeriksaan FAIL.
Prinsip: turunkan ulang status dari flag di file hasil memakai aturan terpisah dari dedup.evaluate (bukan menyalin).
"""
import argparse, csv, json, os, random, sys
from collections import Counter, defaultdict

from namematch import NAME_OK, NAME_WEAK, name_similarity

STATUSES = {"MATCH", "PROBABLE", "REVIEW", "NO_MATCH"}
ACTION = {"MATCH": "HOLD_EXISTING_CUSTOMER", "PROBABLE": "HOLD_EXISTING_CUSTOMER",
          "REVIEW": "HOLD_MANUAL_REVIEW", "NO_MATCH": "SEND_WELCOME_PACK"}
T = lambda v: str(v).strip() == "True"


def hsbc_ids(path, rec_col):
    ids = []
    with open(path, newline="", encoding="utf-8-sig") as f:
        for n, r in enumerate(csv.DictReader(f), start=1):
            ids.append((r.get(rec_col, "") or "").strip() or str(n))
    return ids


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--result", required=True)
    ap.add_argument("--hsbc", required=True)
    ap.add_argument("--map", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--sample", type=int, default=40)
    ap.add_argument("--seed", type=int, default=7)
    a = ap.parse_args()
    os.makedirs(a.out_dir, exist_ok=True)
    rows = list(csv.DictReader(open(a.result, newline="", encoding="utf-8-sig")))
    mp = json.load(open(a.map, encoding="utf-8"))
    src_ids = hsbc_ids(a.hsbc, mp["hsbc"].get("rec_id", ""))
    checks = []

    def add(cid, ok, detail, viol=None, level="FAIL"):
        checks.append({"id": cid, "status": "PASS" if ok else level, "detail": detail, "violations": (viol or [])[:25],
                       "n_violations": len(viol or [])})

    # C1/C2 rekonsiliasi
    res_ids = [r["hsbc_rec_id"] for r in rows]
    dup = [k for k, v in Counter(res_ids).items() if v > 1]
    add("C1_jumlah_baris", len(rows) == len(src_ids), f"input={len(src_ids)} output={len(rows)}")
    add("C2_cakupan_id", set(res_ids) == set(src_ids) and not dup,
        f"hilang={len(set(src_ids) - set(res_ids))} berlebih={len(set(res_ids) - set(src_ids))} duplikat={len(dup)}",
        sorted((set(src_ids) ^ set(res_ids)) | set(dup)))
    # C3 status & aksi
    bad = [r["hsbc_rec_id"] for r in rows if r["status"] not in STATUSES or r["suggested_action"] != ACTION.get(r["status"])]
    add("C3_status_dan_aksi_konsisten", not bad, f"{len(bad)} baris tidak konsisten", bad)
    # C4 MATCH wajib 3 primary
    bad = [r["hsbc_rec_id"] for r in rows if r["status"] == "MATCH" and not (T(r["name_ok"]) and T(r["dob_ok"]) and T(r["id_ok"]))]
    add("C4_match_wajib_3_primary", not bad, f"{len(bad)} MATCH tanpa 3 primary", bad)
    # C5 turunkan ulang status (aturan independen)
    wrong = []
    for r in rows:
        if r["status"] == "NO_MATCH":
            continue
        p = T(r["name_ok"]) + T(r["dob_ok"]) + T(r["id_ok"])
        sup = 2 * (T(r["sid_ok"]) + T(r["npwp_ok"])) + T(r["mother_ok"]) + T(r["phone_ok"]) + T(r["email_ok"])
        try:
            ns = float(r["name_score"])
        except ValueError:
            ns = 0.0
        reasons = r.get("reasons", "")
        near = (not T(r["name_ok"]) and NAME_WEAK <= ns < NAME_OK) or ("id_beda_1_digit" in reasons and not T(r["id_ok"])) \
            or ("dob_near" in reasons and not T(r["dob_ok"]))
        if p == 3:
            exp = {"MATCH"}
        elif "nama+dob sama tapi ID beda" in reasons:
            exp = {"REVIEW"}
        elif p == 2:
            exp = {"PROBABLE"} if sup >= (1 if near else 2) else {"REVIEW"}
        else:
            exp = {"REVIEW"}  # p<=1 hanya boleh REVIEW (selain NO_MATCH)
        if r["status"] not in exp:
            wrong.append(r["hsbc_rec_id"])
    add("C5_status_sesuai_aturan", not wrong, f"{len(wrong)} baris status tidak sesuai turunan ulang", wrong)
    # C6 NO_MATCH bersih
    bad = [r["hsbc_rec_id"] for r in rows if r["status"] == "NO_MATCH" and (r["ocbc_rec_id"] or str(r["n_candidates"]) not in ("0", ""))]
    add("C6_no_match_tanpa_kandidat", not bad, f"{len(bad)} NO_MATCH masih punya kandidat", bad)
    # C7 skor nama konsisten dengan namematch saat ini
    bad = []
    for r in rows:
        if r["status"] != "NO_MATCH" and r["hsbc_name"] and r["ocbc_name"] and r["name_score"]:
            if abs(name_similarity(r["hsbc_name"], r["ocbc_name"])["score"] - float(r["name_score"])) > 0.002:
                bad.append(r["hsbc_rec_id"])
    add("C7_skor_nama_reproducible", not bad, f"{len(bad)} skor nama beda dengan hitung ulang (versi rule berbeda / file diubah)", bad)
    # C8 satu rule_version
    rv = Counter(r["rule_version"] for r in rows)
    add("C8_satu_rule_version", len(rv) == 1, f"versi: {dict(rv)}")
    # C9 many-to-one (peringatan)
    tgt = defaultdict(list)
    for r in rows:
        if r["status"] in ("MATCH", "PROBABLE") and r["ocbc_rec_id"]:
            tgt[r["ocbc_rec_id"]].append(r["hsbc_rec_id"])
    m2o = {k: v for k, v in tgt.items() if len(v) > 1}
    add("C9_satu_nasabah_ocbc_dipakai_banyak_hsbc", not m2o,
        f"{len(m2o)} nasabah OCBC cocok ke >1 nasabah HSBC (bisa duplikat internal HSBC atau salah match)",
        sorted(h for v in m2o.values() for h in v), level="WARN")
    # C10 distribusi (informasi)
    dist = Counter(r["status"] for r in rows)
    warn = len(rows) > 0 and (dist["NO_MATCH"] == len(rows) or dist["MATCH"] > 0.5 * len(rows))
    add("C10_distribusi_status", not warn, f"{dict(dist)}", level="WARN")
    dq = Counter(f for r in rows for f in (r.get("hsbc_dq_flags") or "").split(";") if f)
    add("C11_flag_kualitas_data", True, f"{dict(dq)}")

    # sampel dan zona abu-abu (hanya nama)
    rnd = random.Random(a.seed)
    sample = []
    for st in ("MATCH", "PROBABLE", "REVIEW"):
        pool = [r for r in rows if r["status"] == st]
        sample += rnd.sample(pool, min(a.sample, len(pool)))
    cols = ["hsbc_rec_id", "ocbc_rec_id", "status", "name_score", "reasons", "hsbc_name", "ocbc_name"]
    with open(os.path.join(a.out_dir, "qa_sample.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore"); w.writeheader(); w.writerows(sample)
    grey = [r for r in rows if r["status"] != "NO_MATCH" and r["name_score"] and
            (0.60 <= float(r["name_score"]) < 0.90 or (T(r["dob_ok"]) and T(r["id_ok"]) and not T(r["name_ok"])))]
    with open(os.path.join(a.out_dir, "grey_names.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore"); w.writeheader(); w.writerows(grey)

    overall = "FAIL" if any(c["status"] == "FAIL" for c in checks) else ("PASS_WITH_WARNINGS" if any(c["status"] == "WARN" for c in checks) else "PASS")
    rep = {"overall": overall, "result_file": os.path.basename(a.result), "rows": len(rows), "checks": checks,
           "qa_sample_rows": len(sample), "grey_name_rows": len(grey)}
    json.dump(rep, open(os.path.join(a.out_dir, "check_report.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({"overall": overall, "rows": len(rows), "qa_sample_rows": len(sample), "grey_name_rows": len(grey),
                      "checks": {c["id"]: c["status"] for c in checks}}, ensure_ascii=False, indent=1))
    sys.exit(1 if overall == "FAIL" else 0)


if __name__ == "__main__":
    main()
