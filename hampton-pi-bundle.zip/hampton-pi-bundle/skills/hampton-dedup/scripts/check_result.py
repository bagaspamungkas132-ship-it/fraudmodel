#!/usr/bin/env python3
"""Checker deterministik untuk hasil dedup.py / apply_name_judgments.py (peran: CHECKER, independen dari maker). Stdlib only.

Usage:
  python check_result.py --result result.csv --hsbc hsbc.csv --map mapping.json --out-dir checks/ [--sample 40 --seed 7]

Menulis ke --out-dir:
  check_report.json   verdict PASS/FAIL + hasil tiap pemeriksaan (tanpa data pribadi; hanya rec_id)
  qa_sample.csv       sampel acak per status untuk dicek manual/AI (nama saja, tanpa ID/DOB/HP/email)
  grey_names.csv      pasangan nama zona abu-abu yang belum dinilai LLM (nama saja)
  llm_resample_blind.csv  sampel pasangan yang sudah dinilai judge, TANPA verdict judge (untuk penilaian ulang buta oleh checker)
  llm_resample_key.csv    verdict judge untuk sampel itu (jangan dibuka sebelum penilaian ulang selesai); bandingkan dengan compare_resample.py
Exit code 1 bila ada pemeriksaan FAIL.
Prinsip: turunkan ulang status dari flag di file hasil memakai aturan terpisah dari dedup.evaluate (bukan menyalin).
"""
import argparse, csv, json, os, random, sys
from collections import Counter, defaultdict

from namematch import NAME_OK, NAME_WEAK, name_similarity

STATUSES = {"MATCH", "PROBABLE", "REVIEW", "NO_MATCH"}
ACTION = {"MATCH": "HOLD_EXISTING_CUSTOMER", "PROBABLE": "HOLD_EXISTING_CUSTOMER",
          "REVIEW": "HOLD_MANUAL_REVIEW", "NO_MATCH": "SEND_WELCOME_PACK"}
T = lambda v: str(v).strip() == "True"


def hsbc_ids(path, rec_col):
    ids = []
    with open(path, newline="", encoding="utf-8-sig") as f:
        for n, r in enumerate(csv.DictReader(f), start=1):
            ids.append((r.get(rec_col, "") or "").strip() or str(n))
    return ids


def derive(r, name_ok, name_hint):
    """Turunkan status dari flag di file hasil. Implementasi TERPISAH dari policy.py (sengaja diduplikasi); ubah keduanya bila kebijakan berubah."""
    reasons = r.get("reasons", "")
    has = "id_near" in r
    dob_ok, id_ok = T(r["dob_ok"]), T(r["id_ok"])
    id_near = T(r["id_near"]) if has else ("id_beda_1_digit" in reasons)
    dob_near = T(r["dob_near"]) if has else ("dob_near" in reasons)
    id_conflict = T(r["id_conflict"]) if has else ("nama+dob sama tapi ID beda" in reasons)
    sec = T(r["sid_ok"]) + T(r["npwp_ok"])
    sup = 2 * sec + T(r["mother_ok"]) + T(r["phone_ok"]) + T(r["email_ok"])
    try:
        ns = float(r["name_score"])
    except ValueError:
        ns = 0.0
    weak = (not name_ok) and NAME_WEAK <= ns < NAME_OK
    p = name_ok + dob_ok + id_ok
    near = weak or (not id_ok and id_near) or (not dob_ok and dob_near)
    if p == 3:
        return "MATCH"
    if id_conflict and name_ok and dob_ok:
        return "REVIEW"
    if p == 2:
        if not name_ok and name_hint:
            return "REVIEW"
        return "PROBABLE" if sup >= (1 if near else 2) else "REVIEW"
    if p == 1 and sup >= 2:
        return "REVIEW"
    if id_ok and (weak or dob_near or sup >= 1):
        return "REVIEW"
    if p == 0 and sec == 2:
        return "REVIEW"
    return "NO_MATCH"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--result", required=True)
    ap.add_argument("--hsbc", required=True)
    ap.add_argument("--map", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--sample", type=int, default=40)
    ap.add_argument("--llm-sample", type=int, default=30)
    ap.add_argument("--seed", type=int, default=7)
    a = ap.parse_args()
    os.makedirs(a.out_dir, exist_ok=True)
    rows = list(csv.DictReader(open(a.result, newline="", encoding="utf-8-sig")))
    mp = json.load(open(a.map, encoding="utf-8"))
    src_ids = hsbc_ids(a.hsbc, mp["hsbc"].get("rec_id", ""))
    checks = []

    def add(cid, ok, detail, viol=None, level="FAIL"):
        checks.append({"id": cid, "status": "PASS" if ok else level, "detail": detail, "violations": (viol or [])[:25],
                       "n_violations": len(viol or [])})

    is_llm = lambda r: str(r.get("decision_basis", "")).startswith("RULE+LLM")
    name_final = lambda r: T(r["name_ok"]) or T(r.get("name_ok_llm", ""))
    res_ids = [r["hsbc_rec_id"] for r in rows]
    dup = [k for k, v in Counter(res_ids).items() if v > 1]
    add("C1_jumlah_baris", len(rows) == len(src_ids), f"input={len(src_ids)} output={len(rows)}")
    add("C2_cakupan_id", set(res_ids) == set(src_ids) and not dup,
        f"hilang={len(set(src_ids) - set(res_ids))} berlebih={len(set(res_ids) - set(src_ids))} duplikat={len(dup)}",
        sorted((set(src_ids) ^ set(res_ids)) | set(dup)))
    bad = [r["hsbc_rec_id"] for r in rows if r["status"] not in STATUSES or r["suggested_action"] != ACTION.get(r["status"])]
    add("C3_status_dan_aksi_konsisten", not bad, f"{len(bad)} baris tidak konsisten", bad)
    bad = [r["hsbc_rec_id"] for r in rows if r["status"] == "MATCH" and not (name_final(r) and T(r["dob_ok"]) and T(r["id_ok"]))]
    add("C4_match_wajib_3_primary", not bad, f"{len(bad)} MATCH tanpa 3 primary (nama bisa dari rule atau LLM-SAME; DOB dan ID wajib persis)", bad)
    wrong = []
    for r in rows:
        if r["status"] == "NO_MATCH":
            continue
        hint = bool(r.get("name_flags", ""))
        if is_llm(r):
            v = r.get("llm_verdict", "")
            exp = r["status_rule"] if v == "UNSURE" else derive(r, v == "SAME", v == "DIFFERENT")
        else:
            exp = derive(r, T(r["name_ok"]), hint)
        if r["status"] != exp:
            wrong.append(r["hsbc_rec_id"])
    add("C5_status_sesuai_aturan", not wrong, f"{len(wrong)} baris status tidak sesuai turunan ulang", wrong)
    bad = [r["hsbc_rec_id"] for r in rows if r["status"] == "NO_MATCH" and (r["ocbc_rec_id"] or str(r["n_candidates"]) not in ("0", ""))]
    add("C6_no_match_tanpa_kandidat", not bad, f"{len(bad)} NO_MATCH masih punya kandidat", bad)
    bad = []
    for r in rows:
        if r["status"] != "NO_MATCH" and r["hsbc_name"] and r["ocbc_name"] and r["name_score"]:
            if abs(name_similarity(r["hsbc_name"], r["ocbc_name"])["score"] - float(r["name_score"])) > 0.002:
                bad.append(r["hsbc_rec_id"])
    add("C7_skor_nama_reproducible", not bad, f"{len(bad)} skor nama beda dengan hitung ulang (versi rule berbeda / file diubah)", bad)
    rv = Counter(r["rule_version"] for r in rows)
    add("C8_satu_rule_version", len(rv) == 1, f"versi: {dict(rv)}")
    tgt = defaultdict(list)
    for r in rows:
        if r["status"] in ("MATCH", "PROBABLE") and r["ocbc_rec_id"]:
            tgt[r["ocbc_rec_id"]].append(r["hsbc_rec_id"])
    m2o = {k: v for k, v in tgt.items() if len(v) > 1}
    add("C9_satu_nasabah_ocbc_dipakai_banyak_hsbc", not m2o,
        f"{len(m2o)} nasabah OCBC cocok ke >1 nasabah HSBC (bisa duplikat internal HSBC atau salah match)",
        sorted(h for v in m2o.values() for h in v), level="WARN")
    dist = Counter(r["status"] for r in rows)
    warn = len(rows) > 0 and (dist["NO_MATCH"] == len(rows) or dist["MATCH"] > 0.5 * len(rows))
    add("C10_distribusi_status", not warn, f"{dict(dist)}", level="WARN")
    dq = Counter(f for r in rows for f in (r.get("hsbc_dq_flags") or "").split(";") if f)
    add("C11_flag_kualitas_data", True, f"{dict(dq)}")
    # C12 kebijakan LLM
    bad = [r["hsbc_rec_id"] for r in rows if (r.get("llm_verdict") and not is_llm(r)) or (is_llm(r) and r.get("llm_verdict") not in ("SAME", "DIFFERENT", "UNSURE"))
           or (r["status"] != r.get("status_rule", r["status"]) and not (is_llm(r) and r.get("llm_verdict") in ("SAME", "DIFFERENT")))]
    add("C12_kebijakan_llm_dipatuhi", not bad, f"{len(bad)} baris melanggar: verdict tidak sah, basis keputusan tidak konsisten, atau status berubah tanpa verdict SAME/DIFFERENT", bad)
    pend = [r["hsbc_rec_id"] for r in rows if r["status"] != "NO_MATCH" and not T(r["name_ok"]) and not r.get("llm_verdict")
            and r.get("name_tier") in ("WEAK", "DIFFERENT") and (T(r["dob_ok"]) or T(r["id_ok"]) or T(r.get("id_near", "")) or T(r.get("dob_near", "")))]
    add("C14_pasangan_nama_belum_dinilai_llm", not pend, f"{len(pend)} baris layak dinilai LLM tapi belum (tahap judge dilewati atau antrean belum diterapkan)", pend, level="WARN")

    rnd = random.Random(a.seed)
    sample = []
    for st in ("MATCH", "PROBABLE", "REVIEW"):
        pool = [r for r in rows if r["status"] == st]
        sample += rnd.sample(pool, min(a.sample, len(pool)))
    cols = ["hsbc_rec_id", "ocbc_rec_id", "status", "name_score", "reasons", "hsbc_name", "ocbc_name"]
    with open(os.path.join(a.out_dir, "qa_sample.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore"); w.writeheader(); w.writerows(sample)
    grey = [r for r in rows if r["status"] != "NO_MATCH" and not r.get("llm_verdict") and r["name_score"] and
            (0.60 <= float(r["name_score"]) < 0.90 or (T(r["dob_ok"]) and T(r["id_ok"]) and not T(r["name_ok"])))]
    with open(os.path.join(a.out_dir, "grey_names.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore"); w.writeheader(); w.writerows(grey)
    # resample buta untuk penilaian LLM
    llm_rows = {}
    for r in rows:
        if is_llm(r) and r.get("pair_key"):
            llm_rows.setdefault(r["pair_key"], r)
    by_v = defaultdict(list)
    for k, r in llm_rows.items():
        by_v[r["llm_verdict"]].append(r)
    rs = []
    for v, pool in by_v.items():
        rs += rnd.sample(pool, min(max(1, a.llm_sample // 3), len(pool)))
    with open(os.path.join(a.out_dir, "llm_resample_blind.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["pair_key", "name_a", "name_b"]); w.writerows([[r["pair_key"], r["hsbc_name"], r["ocbc_name"]] for r in rs])
    with open(os.path.join(a.out_dir, "llm_resample_key.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["pair_key", "judge_verdict"]); w.writerows([[r["pair_key"], r["llm_verdict"]] for r in rs])

    overall = "FAIL" if any(c["status"] == "FAIL" for c in checks) else ("PASS_WITH_WARNINGS" if any(c["status"] == "WARN" for c in checks) else "PASS")
    rep = {"overall": overall, "result_file": os.path.basename(a.result), "rows": len(rows), "checks": checks,
           "qa_sample_rows": len(sample), "grey_name_rows": len(grey), "llm_resample_rows": len(rs), "llm_judged_pairs": len(llm_rows)}
    json.dump(rep, open(os.path.join(a.out_dir, "check_report.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({"overall": overall, "rows": len(rows), "qa_sample_rows": len(sample), "grey_name_rows": len(grey),
                      "llm_judged_pairs": len(llm_rows), "llm_resample_rows": len(rs),
                      "checks": {c["id"]: c["status"] for c in checks}}, ensure_ascii=False, indent=1))
    sys.exit(1 if overall == "FAIL" else 0)


if __name__ == "__main__":
    main()
