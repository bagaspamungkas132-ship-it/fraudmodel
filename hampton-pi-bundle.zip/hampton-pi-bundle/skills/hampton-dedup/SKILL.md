---
name: hampton-dedup
description: Dedup nasabah Project Hampton (HSBC -> OCBC) - cek apakah nasabah HSBC yang diakuisisi sudah jadi nasabah OCBC sebelum welcome pack dikirim, berdasarkan nama (fuzzy), DOB, ID number, SID, NPWP, nama ibu kandung, HP, email. Gunakan setiap kali user menyebut hampton, dedup nasabah, cek duplikat, matching HSBC vs OCBC, kemiripan nama (gelar, singkatan, typo, urutan terbalik), NIK/KTP, atau minta membangun/menjalankan/memperbaiki pipeline pencocokan nasabah, meskipun user tidak menyebut kata "skill". Untuk validasi HP/email/alamat gunakan skill hampton-validate-contact.
---

# Hampton Dedup

Tujuan: untuk setiap nasabah HSBC, tentukan apakah dia sudah nasabah OCBC, supaya welcome pack tidak salah kirim.
Konteks project lengkap ada di AGENTS.md. Validasi HP/email/alamat bukan bagian skill ini (lihat `hampton-validate-contact`).

## Aturan keputusan (sumber kebenaran: dari user)

| Level | Field | Perlakuan |
|---|---|---|
| Primary | Nama (fuzzy), DOB, ID Number | 3-3nya cocok = **MATCH** |
| Secondary | SID, NPWP | penguat |
| Tertiary | Nama ibu kandung, no HP, email | penguat lemah |

Status hasil:
- **MATCH**: 3 primary cocok.
- **PROBABLE**: 2 primary cocok + penguat cukup (1 secondary, atau 2 tertiary; cukup 1 penguat kalau primary ketiga "hampir cocok").
- **REVIEW**: sinyal campuran, near-miss (ID beda 1 digit, hari-bulan DOB tertukar), atau ID beda tapi nama+DOB sama (kembar / salah input). Manusia yang memutuskan.
- **NO_MATCH**: tidak ada sinyal berarti.

Saran aksi (`suggested_action`): MATCH/PROBABLE -> tahan welcome pack nasabah baru; REVIEW -> tahan sampai direview; NO_MATCH -> boleh kirim. Keputusan akhir ada di business owner, bukan di agent.

Penguat tidak pernah bisa mengubah status sendirian menjadi MATCH. HP/email yang dummy, tidak valid, atau dipakai banyak record (keluarga, agen) diabaikan.

## Alur kerja

1. **Profil data dulu.** Jumlah baris, null rate per kolom, format DOB, panjang ID (NIK 16 digit), duplikat internal. Jangan menebak format.
2. **Mapping kolom.** Salin `examples/mapping.example.json`, sesuaikan nama kolom HSBC dan OCBC. Tanyakan ke user kalau ada kolom yang ambigu.
3. **Jalankan.**
   ```
   python scripts/dedup.py --hsbc <hsbc.csv> --ocbc <ocbc.csv> --map mapping.json --out result.csv
   ```
   Untuk data sangat besar (jutaan baris OCBC), script stdlib ini cocok untuk uji dan data menengah; produksi: porting logika dan blocking key yang sama ke DuckDB/Polars/Spark (lihat references).
4. **QA sebelum percaya hasil.** Sampel acak ~100 baris per status (terutama PROBABLE, REVIEW, dan NO_MATCH dengan `n_candidates` > 0), cek manual bersama user, hitung false positive/negative, sesuaikan threshold atau kamus nama. Tambahkan kasus yang salah ke `scripts/test_namematch.py`.
5. **Laporan.** Jumlah per status, flag kualitas data, daftar REVIEW, `rule_version`, tanggal run.

## Maker-checker dan audit (bila memakai sub-agent)
- **Maker** (`hampton-maker`) menjalankan `dedup.py`. **Checker** (`hampton-checker`) memeriksa hasil dengan `scripts/check_result.py` (rekonsiliasi, MATCH wajib 3 primary, status diturunkan ulang dengan aturan terpisah, skor nama reproducible, sampel QA, daftar nama zona abu-abu) dan menilai nama zona abu-abu dengan AI.
- **Auditor** bukan agent: `python scripts/audit_run.py ...` membuat jejak run (hash input, versi rule, parameter, rekonsiliasi, verdict checker, perubahan vs run sebelumnya) tanpa data pribadi.
- Pemeriksaan deterministik dan jejak audit tidak butuh AI dan tidak mengirim data ke model. AI hanya menilai nama zona abu-abu dan hanya memberi saran; ia tidak mengubah status.

## Tes cepat
```
python scripts/namematch.py "Dr. Ir. H. Budi Santoso, M.M." "BUDI SANTOSO"
python scripts/test_namematch.py
```
Nama dianggap sama jika skor >= 0.85; 0.70-0.85 hanya "mirip".

## Guardrail data (wajib)
- Data nasabah = PII + rahasia bank. Proses lokal; jangan upload ke layanan eksternal; jangan commit ke git.
- Jangan tampilkan NIK/NPWP/SID/HP/email mentah di chat atau log (mask, mis. `3171********0001`). Output script tidak memuat nomor ID.
- Jangan menempelkan baris data asli ke prompt; kerjakan lewat script, lihat agregat atau sampel ter-mask. Kalau agent memakai model cloud, cek kebijakan data kantor dulu.
- Jangan menimpa file sumber; output ke folder baru bertanggal.
- Setiap hasil bisa ditelusuri: reason code per baris, `rule_version`, input yang dipakai.

## Detail
`references/matching-rules.md`: normalisasi nama, struktur NIK, blocking, edge case (kembar, nama berubah, WNA, nama satu kata, nama terpotong), data quality, QA, ide pengembangan.
