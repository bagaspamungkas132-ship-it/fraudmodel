---
name: hampton-dedup
description: Dedup nasabah Project Hampton (HSBC -> OCBC) - cek apakah nasabah HSBC yang diakuisisi sudah jadi nasabah OCBC sebelum welcome pack dikirim, berdasarkan nama (fuzzy), DOB, ID number, SID, NPWP, nama ibu kandung, HP, email. Gunakan setiap kali user menyebut hampton, dedup nasabah, cek duplikat, matching HSBC vs OCBC, kemiripan nama (gelar, singkatan, typo, urutan terbalik), NIK/KTP, atau minta membangun/menjalankan/memperbaiki pipeline pencocokan nasabah, meskipun user tidak menyebut kata "skill". Untuk validasi HP/email/alamat gunakan skill hampton-validate-contact.
---

# Hampton Dedup

Tujuan: untuk setiap nasabah HSBC, tentukan apakah dia sudah nasabah OCBC, supaya welcome pack tidak salah kirim.
Konteks project lengkap ada di AGENTS.md. Validasi HP/email/alamat bukan bagian skill ini (lihat `hampton-validate-contact`).

## Aturan keputusan (sumber kebenaran: dari user)

| Level | Field | Perlakuan |
|---|---|---|
| Primary | Nama (fuzzy), DOB, ID Number | 3-3nya cocok = **MATCH** |
| Secondary | SID, NPWP | penguat |
| Tertiary | Nama ibu kandung, no HP, email | penguat lemah |

Status hasil:
- **MATCH**: 3 primary cocok.
- **PROBABLE**: 2 primary cocok + penguat cukup (1 secondary, atau 2 tertiary; cukup 1 penguat kalau primary ketiga "hampir cocok").
- **REVIEW**: sinyal campuran, near-miss (ID beda 1 digit, hari-bulan DOB tertukar), atau ID beda tapi nama+DOB sama (kembar / salah input). Manusia yang memutuskan.
- **NO_MATCH**: tidak ada sinyal berarti.

Saran aksi (`suggested_action`): MATCH/PROBABLE -> tahan welcome pack nasabah baru; REVIEW -> tahan sampai direview; NO_MATCH -> boleh kirim. Keputusan akhir ada di business owner, bukan di agent.

Penguat tidak pernah bisa mengubah status sendirian menjadi MATCH. HP/email yang dummy, tidak valid, atau dipakai banyak record (keluarga, agen) diabaikan.

## Alur kerja

1. **Profil data dulu.** Jumlah baris, null rate per kolom, format DOB, panjang ID (NIK 16 digit), duplikat internal. Jangan menebak format.
2. **Mapping kolom.** Salin `examples/mapping.example.json`, sesuaikan nama kolom HSBC dan OCBC. Tanyakan ke user kalau ada kolom yang ambigu.
3. **Jalankan.**
   ```
   python scripts/dedup.py --hsbc <hsbc.csv> --ocbc <ocbc.csv> --map mapping.json --out result.csv
   ```
   Untuk data sangat besar (jutaan baris OCBC), script stdlib ini cocok untuk uji dan data menengah; produksi: porting logika dan blocking key yang sama ke DuckDB/Polars/Spark (lihat references).
4. **QA sebelum percaya hasil.** Sampel acak ~100 baris per status (terutama PROBABLE, REVIEW, dan NO_MATCH dengan `n_candidates` > 0), cek manual bersama user, hitung false positive/negative, sesuaikan threshold atau kamus nama. Tambahkan kasus yang salah ke `scripts/test_namematch.py`.
5. **Laporan.** Jumlah per status, flag kualitas data, daftar REVIEW, `rule_version`, tanggal run.

## Pipeline nama: rule -> judge (LLM) -> checker
- **Tahap 1-2 (rule, `namematch.py`):** normalisasi, skor, `tier` (EXACT/NORMALIZED/VARIANT/WEAK/DIFFERENT/DIFFERENT_HINT) dan `flags` negatif (akhiran gender, generasi, angka). Menangani terpotong, singkatan, inisial beberapa kata, spasi, ejaan, urutan, typo; kata pendek beda 1-2 huruf masuk WEAK (zona abu-abu).
- **Tahap 3 (judge LLM, `hampton-name-judge`):** hanya pasangan WEAK/DIFFERENT yang DOB atau ID-nya cocok/hampir cocok (antrean dari `dedup.py --judge-queue`, hanya nama). Rubrik: `references/name-judge-rubric.md`. Keluaran SAME/DIFFERENT/UNSURE.
- **Penggabung (`apply_name_judgments.py` + `policy.py`):** LLM hanya mengisi penilaian nama; status tetap diturunkan `policy.decide_status`. LLM tidak bisa membuat MATCH bila DOB atau ID tidak cocok persis; UNSURE tidak mengubah status. Kolom `decision_basis` (RULE atau RULE+LLM), `llm_verdict`, `status_rule` menjaga keterlacakan. `--cache` mencegah pasangan yang sama dinilai ulang.
- **Checker (`hampton-checker`, `check_result.py`, `compare_resample.py`):** pemeriksaan deterministik (rekonsiliasi, MATCH wajib 3 primary, status diturunkan ulang dengan implementasi terpisah, skor reproducible, kepatuhan kebijakan LLM) dan penilaian ulang BUTA atas sampel penilaian judge.
- **Auditor** bukan agent: `audit_run.py` mencatat hash input, versi rule, parameter, rekonsiliasi, verdict checker, statistik LLM, dan perubahan vs run sebelumnya, tanpa data pribadi.
- Pemeriksaan deterministik dan audit tidak butuh AI dan tidak mengirim data ke model. Pasangan nama yang dikirim ke judge adalah PII: pastikan model yang dipakai disetujui kantor.
- Setiap perubahan aturan status harus diubah di `policy.py` DAN `check_result.py` (derive) lalu jalankan `test_pipeline.py`.

## Tes cepat
```
python scripts/namematch.py "Dr. Ir. H. Budi Santoso, M.M." "BUDI SANTOSO"
python scripts/test_namematch.py
python scripts/test_pipeline.py
```
Nama dianggap sama jika skor >= 0.85; 0.70-0.85 hanya "mirip".

## Guardrail data (wajib)
- Data nasabah = PII + rahasia bank. Proses lokal; jangan upload ke layanan eksternal; jangan commit ke git.
- Jangan tampilkan NIK/NPWP/SID/HP/email mentah di chat atau log (mask, mis. `3171********0001`). Output script tidak memuat nomor ID.
- Jangan menempelkan baris data asli ke prompt; kerjakan lewat script, lihat agregat atau sampel ter-mask. Kalau agent memakai model cloud, cek kebijakan data kantor dulu.
- Jangan menimpa file sumber; output ke folder baru bertanggal.
- Setiap hasil bisa ditelusuri: reason code per baris, `rule_version`, input yang dipakai.

## Detail
`references/matching-rules.md`: normalisasi nama, struktur NIK, blocking, edge case (kembar, nama berubah, WNA, nama satu kata, nama terpotong), data quality, QA, ide pengembangan.
