#!/usr/bin/env python3
"""Regression tests HP/email/alamat. Jalankan: python test_contact.py. Tambah kasus nyata yang salah parse."""
from validate_contact import phone_info, email_info, parse_address

bad = 0


def check(label, cond):
    global bad
    if not cond:
        bad += 1
        print("FAIL", label)


# phone
check("08xx", phone_info("0812-3456-7890")["norm"] == "6281234567890" and phone_info("0812-3456-7890")["valid"] == "YES")
check("+62", phone_info("+62 812 3456 789")["norm"] == "62812345 6789".replace(" ", ""))
check("dummy", phone_info("08111111111")["valid"] == "NO")
check("pendek", phone_info("0812345")["valid"] == "NO")
check("landline", phone_info("021-5551234")["type"] == "landline")
check("prefix84", phone_info("08412345678")["valid"] == "NO")
check("dua nomor", "hp_lebih_dari_1_nomor" in phone_info("0812345678901 / 0857123456789")["notes"])
# email
check("ok", email_info("Budi.S@Gmail.com")["valid"] == "YES")
check("typo", email_info("budi@gmial.com")["suggestion"] == "budi@gmail.com")
check("format", email_info("budi@@gmail")["valid"] == "NO")
check("placeholder", email_info("test@test.com")["valid"] == "NO")
# address
p = parse_address("Jl. Melati Raya No. 12 RT.003/RW.007 Kel. Cipete Utara Kec. Kebayoran Baru Jakarta Selatan DKI Jakarta 12150")
check("full jalan", p["jalan"] == "MELATI RAYA")
check("full no", p["nomor"] == "12" and p["rt"] == "3" and p["rw"] == "7")
check("full wilayah", p["kelurahan"] == "CIPETE UTARA" and p["kecamatan"] == "KEBAYORAN BARU"
      and p["kota"] == "JAKARTA SELATAN" and p["provinsi"] == "DKI JAKARTA" and p["kodepos"] == "12150")
check("full deliverable", p["deliverable"] == "YES")
p = parse_address("Jl Mawar 5, Bekasi")
check("kurang: kodepos/kec/kel", p["deliverable"] == "CHECK" and "kodepos" in p["missing"] and "kecamatan" in p["missing"])
p = parse_address("Perum Griya Asri Blok C5 No 10 RT 02 RW 05 Desa Sukamaju Kec. Cibitung Kab. Bekasi Jawa Barat 17520")
check("perum", p["komplek_gang"].startswith("PERUM GRIYA ASRI") and p["blok"] == "C5" and p["nomor"] == "10"
      and p["kota"] == "BEKASI" and p["kota_tipe"] == "KABUPATEN" and p["provinsi"] == "JAWA BARAT")
p = parse_address("Apartemen Kalibata City Tower Ebony Lt 12 Unit 12A, Jl. Raya Kalibata, Pancoran, Jakarta Selatan 12750")
check("apartemen", p["gedung"].startswith("APARTEMEN KALIBATA CITY") and p["lantai_unit"] == "LT 12 UNIT 12A")
p = parse_address("SAMA DENGAN KTP")
check("placeholder", p["deliverable"] == "NO")
p = parse_address("Jakarta")
check("kota saja", p["deliverable"] == "NO" and "tidak_ada_jalan_atau_gedung" in p["codes"])
p = parse_address("Jl. Papua No 3 RT 1 RW 2 Kel. Menteng Kec. Menteng Jakarta Pusat 10310")
check("jalan bernama provinsi", p["jalan"] == "PAPUA" and p["provinsi"] == "DKI JAKARTA")
p = parse_address("Jl. Merdeka No 1 Bandung Jawa Barat 12150")
check("kodepos vs provinsi", "kodepos_tidak_cocok_provinsi" in p["codes"])
p = parse_address("Jl. Menteng Raya 3 RT 1/RW 2, Selong, Kebayoran Baru, Jakarta Selatan")
check("nomor tanpa label", p["jalan"] == "MENTENG RAYA" and p["nomor"] == "3")
print("OK" if not bad else f"{bad} gagal")
raise SystemExit(1 if bad else 0)
