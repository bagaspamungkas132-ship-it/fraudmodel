#!/usr/bin/env python3
"""Validasi HP, email, dan parsing alamat free-text Indonesia. Stdlib only.

Usage:
  python validate_contact.py --in hsbc.csv --map mapping_contact.json --out contact_check.csv [--wilayah wilayah.csv]

mapping_contact.json: {"rec_id":"CIF","phone":"HP","email":"EMAIL","address":["ALAMAT1","ALAMAT2","ALAMAT3"]}
  ("address" boleh satu kolom atau daftar kolom; akan digabung)
wilayah.csv (opsional, sangat disarankan): kolom provinsi,kota,kecamatan,kelurahan,kodepos.
  Dipakai untuk memeriksa nama wilayah, mengusulkan koreksi typo, dan mengisi komponen yang hilang.

PENTING: ini validasi FORMAT dan KELENGKAPAN. Script tidak bisa memastikan nomor aktif,
email bisa menerima surat, atau alamat benar-benar ada. Itu butuh verifikasi eksternal (OTP/HLR,
konfirmasi nasabah, geocoding/validasi Pos) yang harus disetujui dulu karena melibatkan PII.
"""
import argparse
import csv
import difflib
import json
import re
import unicodedata
from collections import Counter, defaultdict

# =============================== PHONE ===============================
MOBILE_RE = re.compile(r"^628[1235789]\d+$")


def _phone_one(raw):
    notes = []
    s = raw.strip()
    digits = re.sub(r"\D", "", s)
    if not digits:
        return {"norm": "", "type": "", "valid": "NO", "notes": ["hp_bukan_angka"]}
    if s.startswith("+") and not s.startswith("+62"):
        return {"norm": digits, "type": "foreign", "valid": "CHECK", "notes": ["hp_luar_negeri"]}
    if digits.startswith("00"):
        digits = digits[2:]
    if digits.startswith("62"):
        national = digits[2:].lstrip("0") if digits[2:3] == "0" else digits[2:]
    elif digits.startswith("0"):
        national = digits[1:]
    elif digits.startswith("8"):
        national = digits
    else:
        return {"norm": digits, "type": "", "valid": "NO", "notes": ["hp_format_tidak_dikenal"]}
    norm = "62" + national
    ptype = "mobile" if national.startswith("8") else "landline"
    valid = "YES"
    steps = sum(int(y) - int(x) == 1 for x, y in zip(national, national[1:]))
    steps_down = sum(int(x) - int(y) == 1 for x, y in zip(national, national[1:]))
    if len(set(national)) <= 2 or re.search(r"(\d)\1{6,}", national) or max(steps, steps_down) >= len(national) - 2:
        return {"norm": norm, "type": ptype, "valid": "NO", "notes": ["hp_dummy_atau_berulang"]}
    if ptype == "mobile":
        if not MOBILE_RE.match(norm):
            valid = "NO"
            notes.append("hp_prefix_operator_tidak_dikenal")
        if len(norm) < 11:
            valid = "NO"
            notes.append("hp_terlalu_pendek")
        elif len(norm) > 14:
            valid = "NO"
            notes.append("hp_terlalu_panjang")
    else:
        if not 10 <= len(norm) <= 13:
            valid = "NO"
            notes.append("telepon_rumah_panjang_tidak_wajar")
        else:
            notes.append("telepon_rumah_bukan_hp")
            valid = "CHECK"
    return {"norm": norm, "type": ptype, "valid": valid, "notes": notes}


def phone_info(raw):
    raw = (raw or "").strip()
    if not raw or raw.upper() in {"-", "N/A", "NA", "NULL", "TIDAK ADA", "TDK ADA"}:
        return {"norm": "", "type": "", "valid": "NO", "notes": ["hp_kosong"]}
    parts = [p for p in re.split(r"[,;/]|\bATAU\b|\bDAN\b", raw, flags=re.I) if re.search(r"\d", p)]
    infos = [_phone_one(p) for p in parts] or [_phone_one(raw)]
    best = next((i for i in infos if i["valid"] == "YES"), infos[0])
    if len(infos) > 1:
        best = {**best, "notes": best["notes"] + ["hp_lebih_dari_1_nomor"]}
    return best


def clean_phone(raw):
    """Untuk dedup: nomor ternormalisasi hanya bila valid; selain itu '' (jangan jadi sinyal match)."""
    i = phone_info(raw)
    return i["norm"] if i["valid"] == "YES" else ""


# =============================== EMAIL ===============================
EMAIL_RE = re.compile(r"^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@(?:[a-z0-9-]+\.)+[a-z]{2,}$")
DOMAIN_FIX = {
    "gmial.com": "gmail.com", "gmai.com": "gmail.com", "gmail.co": "gmail.com", "gmail.con": "gmail.com",
    "gamil.com": "gmail.com", "gmail.cm": "gmail.com", "gnail.com": "gmail.com", "gmail.om": "gmail.com",
    "yaho.com": "yahoo.com", "yahooo.com": "yahoo.com", "yahoo.con": "yahoo.com",
    "yahoo.co.od": "yahoo.co.id", "yahoo.coid": "yahoo.co.id", "yahoo.co.i": "yahoo.co.id",
    "hotmal.com": "hotmail.com", "hotmail.con": "hotmail.com", "outlok.com": "outlook.com",
    "outlook.con": "outlook.com", "icloud.con": "icloud.com",
}
DISPOSABLE = {"mailinator.com", "guerrillamail.com", "10minutemail.com", "tempmail.com", "yopmail.com",
              "trashmail.com", "sharklasers.com", "throwawaymail.com"}
PLACEHOLDER_LOCAL = {"test", "tes", "noemail", "none", "tidakada", "tdkada", "xxx", "xx", "abc", "aaa",
                     "email", "na", "nomail", "no.email", "belumpunya", "tidakpunya"}
PLACEHOLDER_DOMAIN = {"test.com", "example.com", "noemail.com", "xxx.com", "email.com", "tidakada.com"}


def email_info(raw):
    raw = (raw or "").strip().lower()
    if not raw or raw in {"-", "n/a", "na", "null", "tidak ada", "tdk ada"}:
        return {"norm": "", "valid": "NO", "notes": ["email_kosong"], "suggestion": ""}
    cands = [c for c in re.split(r"[,;\s]+", raw) if "@" in c] or [raw]
    notes = ["email_lebih_dari_1"] if len(cands) > 1 else []
    e = cands[0].strip(".<>()\"'")
    if not EMAIL_RE.match(e) or ".." in e or e.split("@")[0].startswith(".") or e.split("@")[0].endswith(".") \
            or len(e.split("@")[0]) > 64:
        return {"norm": e, "valid": "NO", "notes": notes + ["email_format_salah"], "suggestion": ""}
    local, dom = e.split("@")
    if local in PLACEHOLDER_LOCAL or dom in PLACEHOLDER_DOMAIN:
        return {"norm": e, "valid": "NO", "notes": notes + ["email_placeholder"], "suggestion": ""}
    if dom in DOMAIN_FIX:
        return {"norm": e, "valid": "CHECK", "notes": notes + ["email_domain_diduga_typo"],
                "suggestion": f"{local}@{DOMAIN_FIX[dom]}"}
    if dom in DISPOSABLE:
        return {"norm": e, "valid": "CHECK", "notes": notes + ["email_sekali_pakai"], "suggestion": ""}
    return {"norm": e, "valid": "YES", "notes": notes, "suggestion": ""}


def clean_email(raw):
    i = email_info(raw)
    return i["norm"] if i["valid"] == "YES" else ""


# =============================== ADDRESS ===============================
PROVINCES = {
    "ACEH": ["NAD", "NANGGROE ACEH DARUSSALAM"], "SUMATERA UTARA": ["SUMUT", "SUMATRA UTARA"],
    "SUMATERA BARAT": ["SUMBAR", "SUMATRA BARAT"], "RIAU": [], "KEPULAUAN RIAU": ["KEPRI"], "JAMBI": [],
    "SUMATERA SELATAN": ["SUMSEL", "SUMATRA SELATAN"], "KEPULAUAN BANGKA BELITUNG": ["BANGKA BELITUNG", "BABEL"],
    "BENGKULU": [], "LAMPUNG": [], "DKI JAKARTA": ["DKI", "D K I JAKARTA", "PROVINSI DKI JAKARTA"],
    "BANTEN": [], "JAWA BARAT": ["JABAR"], "JAWA TENGAH": ["JATENG"],
    "DI YOGYAKARTA": ["DIY", "D I YOGYAKARTA", "DAERAH ISTIMEWA YOGYAKARTA"], "JAWA TIMUR": ["JATIM"],
    "BALI": [], "NUSA TENGGARA BARAT": ["NTB"], "NUSA TENGGARA TIMUR": ["NTT"],
    "KALIMANTAN BARAT": ["KALBAR"], "KALIMANTAN TENGAH": ["KALTENG"], "KALIMANTAN SELATAN": ["KALSEL"],
    "KALIMANTAN TIMUR": ["KALTIM"], "KALIMANTAN UTARA": ["KALTARA"], "SULAWESI UTARA": ["SULUT"],
    "SULAWESI TENGAH": ["SULTENG"], "SULAWESI SELATAN": ["SULSEL"], "SULAWESI TENGGARA": ["SULTRA"],
    "GORONTALO": [], "SULAWESI BARAT": ["SULBAR"], "MALUKU": [], "MALUKU UTARA": ["MALUT"], "PAPUA": [],
    "PAPUA BARAT": [], "PAPUA BARAT DAYA": [], "PAPUA SELATAN": [], "PAPUA TENGAH": [], "PAPUA PEGUNUNGAN": [],
}
PROV_ALIAS = sorted(((a, p) for p, al in PROVINCES.items() for a in [p] + al), key=lambda x: -len(x[0]))
CITY_PROV = {  # kota/kab yang umum ditulis tanpa penanda -> provinsi (hanya yang tidak ambigu)
    "JAKARTA SELATAN": "DKI JAKARTA", "JAKARTA UTARA": "DKI JAKARTA", "JAKARTA BARAT": "DKI JAKARTA",
    "JAKARTA TIMUR": "DKI JAKARTA", "JAKARTA PUSAT": "DKI JAKARTA", "KEPULAUAN SERIBU": "DKI JAKARTA",
    "TANGERANG SELATAN": "BANTEN", "TANGERANG": "BANTEN", "SERANG": "BANTEN", "CILEGON": "BANTEN",
    "BEKASI": "JAWA BARAT", "DEPOK": "JAWA BARAT", "BOGOR": "JAWA BARAT", "BANDUNG": "JAWA BARAT",
    "BANDUNG BARAT": "JAWA BARAT", "CIMAHI": "JAWA BARAT", "CIREBON": "JAWA BARAT", "SUKABUMI": "JAWA BARAT",
    "TASIKMALAYA": "JAWA BARAT", "KARAWANG": "JAWA BARAT", "SEMARANG": "JAWA TENGAH", "SURAKARTA": "JAWA TENGAH",
    "SOLO": "JAWA TENGAH", "YOGYAKARTA": "DI YOGYAKARTA", "SLEMAN": "DI YOGYAKARTA", "BANTUL": "DI YOGYAKARTA",
    "MALANG": "JAWA TIMUR", "SURABAYA": "JAWA TIMUR", "SIDOARJO": "JAWA TIMUR", "GRESIK": "JAWA TIMUR",
    "MEDAN": "SUMATERA UTARA", "PALEMBANG": "SUMATERA SELATAN", "PEKANBARU": "RIAU", "BATAM": "KEPULAUAN RIAU",
    "PADANG": "SUMATERA BARAT", "BANDAR LAMPUNG": "LAMPUNG", "BALIKPAPAN": "KALIMANTAN TIMUR",
    "SAMARINDA": "KALIMANTAN TIMUR", "BANJARMASIN": "KALIMANTAN SELATAN", "PONTIANAK": "KALIMANTAN BARAT",
    "MAKASSAR": "SULAWESI SELATAN", "MANADO": "SULAWESI UTARA", "DENPASAR": "BALI", "BADUNG": "BALI",
    "MATARAM": "NUSA TENGGARA BARAT", "KUPANG": "NUSA TENGGARA TIMUR", "JAYAPURA": "PAPUA", "AMBON": "MALUKU",
}
CITY_NAMES = sorted(CITY_PROV, key=lambda c: -len(c))
PROV_NAMES = [a for a, _ in PROV_ALIAS]
AMBIG_KOTA_KAB = {"BOGOR", "BEKASI", "TANGERANG", "BANDUNG", "SEMARANG", "MALANG", "CIREBON", "SUKABUMI",
                  "TASIKMALAYA", "MAGELANG", "KEDIRI", "MADIUN"}
ADMIN = {"KEL": "kelurahan", "KELURAHAN": "kelurahan", "DESA": "kelurahan", "DS": "kelurahan",
         "KEC": "kecamatan", "KECAMATAN": "kecamatan", "KAB": "kota", "KABUPATEN": "kota",
         "KOTA": "kota", "KOTAMADYA": "kota", "KODYA": "kota", "PROV": "provinsi", "PROVINSI": "provinsi"}
STREET_JL = {"JL", "JALAN", "JLN"}
STREET_OTHER = {"GG", "GANG", "LRG", "LORONG", "KOMP", "KOMPLEK", "KOMPLEKS", "PERUM", "PERUMAHAN",
                "CLUSTER", "KP", "KAMPUNG", "DUSUN", "DSN"}
BUILDING = {"APARTEMEN", "APARTMENT", "APT", "RUSUN", "RUSUNAWA", "RUSUNAMI", "MENARA", "GEDUNG", "GD", "TOWER"}
STOP = {"NO", "BLOK", "RT", "RW", "LT", "UNIT", "KAV", "KAVLING"}
PLACEHOLDER_ADDR = re.compile(r"^(-+|\.+|N/?A|NULL|NONE|TIDAK ADA|TDK ADA|SAMA DENGAN (ALAMAT )?KTP|SESUAI KTP|"
                              r"ALAMAT (KTP|RUMAH|SESUAI KTP))$")
FIELD_LIMITS = {30, 35, 40, 50, 60}

MSG = {
    "alamat_kosong": "alamat kosong / placeholder",
    "tidak_ada_jalan_atau_gedung": "tidak ada nama jalan/komplek/gedung/dusun",
    "kota_kosong": "kota/kabupaten tidak ada",
    "provinsi_kosong": "provinsi tidak ada",
    "kecamatan_kosong": "kecamatan tidak ada",
    "kelurahan_kosong": "kelurahan/desa tidak ada",
    "kodepos_kosong": "kode pos tidak ada",
    "kodepos_bukan_5_digit": "kode pos bukan 5 digit",
    "nomor_rumah_kosong": "nomor rumah/blok tidak ada",
    "rt_rw_kosong": "RT/RW tidak ada",
    "rt_atau_rw_saja": "hanya salah satu RT atau RW yang ada",
    "kodepos_tidak_cocok_provinsi": "kode pos tidak cocok dengan provinsi",
    "po_box": "PO Box (bukan alamat rumah)",
    "kemungkinan_terpotong": "panjang teks pas di batas field, kemungkinan terpotong",
    "kota_atau_kab_tidak_jelas": "kota atau kabupaten tidak jelas (nama ada di keduanya)",
    "komponen_ditebak_dari_urutan": "kelurahan/kecamatan/kota ditebak dari urutan teks, perlu verifikasi",
    "teks_sisa_tidak_terpetakan": "ada teks yang tidak terpetakan ke komponen alamat",
    "alamat_terlalu_pendek": "alamat terlalu pendek",
}
SEV = {"alamat_kosong": "KRITIS", "tidak_ada_jalan_atau_gedung": "KRITIS", "kota_kosong": "KRITIS",
       "rt_rw_kosong": "INFO", "nomor_rumah_kosong": "PERLU_CEK", "kodepos_bukan_5_digit": "PERLU_CEK"}


def _ascii_upper(s):
    return unicodedata.normalize("NFKD", str(s or "")).encode("ascii", "ignore").decode().upper()


def _norm_key(s):  # untuk membandingkan nama wilayah
    s = re.sub(r"\b(KOTA|KAB|KABUPATEN|ADM|ADMINISTRASI|KECAMATAN|KEC|KELURAHAN|KEL|DESA)\b", " ", _ascii_upper(s))
    return re.sub(r"[^A-Z0-9]", "", s)


class Wilayah:
    def __init__(self, path):
        self.rows = []
        with open(path, newline="", encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                self.rows.append({k: _ascii_upper(r.get(k, "")).strip() for k in
                                  ("provinsi", "kota", "kecamatan", "kelurahan", "kodepos")})
        self.by_kel = defaultdict(list)
        for r in self.rows:
            self.by_kel[_norm_key(r["kelurahan"])].append(r)
        self.kec = {_norm_key(r["kecamatan"]) for r in self.rows}
        self.kota = {_norm_key(r["kota"]) for r in self.rows}

    def check(self, a, add):
        """Validasi/lengkapi komponen alamat `a` memakai tabel referensi. add(code, pesan, severity)."""
        kel, kec, kota = _norm_key(a["kelurahan"]), _norm_key(a["kecamatan"]), _norm_key(a["kota"])
        rows = self.rows
        if kota:
            if kota in self.kota:
                rows = [r for r in rows if _norm_key(r["kota"]) == kota]
            else:
                sug = difflib.get_close_matches(kota, list(self.kota), 1, 0.85)
                add("kota_tidak_ada_di_referensi", "kota/kab '%s' tidak ada di referensi%s" % (
                    a["kota"], f"; usulan: {sug[0]}" if sug else ""), "PERLU_CEK")
        if kec:
            sub = [r for r in rows if _norm_key(r["kecamatan"]) == kec]
            if sub:
                rows = sub
            else:
                sug = difflib.get_close_matches(kec, list({_norm_key(r['kecamatan']) for r in rows}), 1, 0.85)
                name = next((r["kecamatan"] for r in rows if _norm_key(r["kecamatan"]) == sug[0]), "") if sug else ""
                add("kecamatan_tidak_ada_di_referensi", "kecamatan '%s' tidak ada di referensi%s" % (
                    a["kecamatan"], f"; usulan: {name}" if name else ""), "PERLU_CEK")
        if kel:
            sub = [r for r in rows if _norm_key(r["kelurahan"]) == kel]
            if not sub:
                sug = difflib.get_close_matches(kel, list({_norm_key(r['kelurahan']) for r in rows}), 1, 0.85)
                name = next((r["kelurahan"] for r in rows if _norm_key(r["kelurahan"]) == sug[0]), "") if sug else ""
                add("kelurahan_tidak_ada_di_referensi", "kelurahan '%s' tidak ada di referensi%s" % (
                    a["kelurahan"], f"; usulan: {name}" if name else ""), "PERLU_CEK")
                return
            rows = sub
        elif not kec:
            return
        uniq = {(r["provinsi"], r["kota"], r["kecamatan"], r["kelurahan"]) for r in rows}
        if len(uniq) == 1:
            prov, kt, kc, kl = next(iter(uniq))
            for key, val in (("provinsi", prov), ("kota", kt), ("kecamatan", kc), ("kelurahan", kl)):
                if val and not a[key]:
                    a[key] = val
                    add("diisi_dari_referensi", f"{key} diisi dari tabel referensi: {val}", "INFO")
        pos = {r["kodepos"] for r in rows if r["kodepos"]}
        if pos and a["kodepos"] and a["kodepos"] not in pos:
            add("kodepos_tidak_sesuai_referensi", "kode pos %s tidak sesuai referensi wilayah (referensi: %s)" % (
                a["kodepos"], "/".join(sorted(pos)[:3])), "PERLU_CEK")
        elif pos and not a["kodepos"] and len(pos) == 1:
            a["kodepos"] = next(iter(pos))
            add("diisi_dari_referensi", f"kode pos diisi dari tabel referensi: {a['kodepos']}", "INFO")


ADDR_FIELDS = ["jalan", "komplek_gang", "nomor", "blok", "gedung", "lantai_unit", "rt", "rw", "kelurahan",
               "kecamatan", "kota", "kota_tipe", "provinsi", "kodepos", "sisa_teks"]


def _take(tokens, i, maxn=4):
    """Ambil token mulai i sampai koma / penanda lain / awal nama provinsi. Return (list, next_index)."""
    out = []
    while i < len(tokens) and len(out) < maxn:
        t = tokens[i]
        rest = " ".join(tokens[i:])
        if t == "," or t in ADMIN or t in STOP or t in STREET_JL or t in STREET_OTHER or t in BUILDING:
            break
        if out and any(rest.startswith(a + " ") or rest == a for a in PROV_NAMES + CITY_NAMES):
            break
        out.append(t)
        i += 1
    return out, i


def parse_address(raw, wilayah=None):
    a = {k: "" for k in ADDR_FIELDS}
    issues = []  # (sev, code, msg)

    def add(code, msg=None, sev=None):
        issues.append((sev or SEV.get(code, "PERLU_CEK"), code, msg or MSG.get(code, code)))

    original = str(raw or "").strip()
    text = _ascii_upper(original)
    text = re.sub(r"[\n\r;|]+", " , ", text)
    if not text.strip() or PLACEHOLDER_ADDR.match(text.strip()):
        add("alamat_kosong")
        return _finish(a, issues, "RENDAH", original)
    if len(original) in FIELD_LIMITS:
        add("kemungkinan_terpotong", sev="INFO")
    if re.search(r"\bP\.?\s?O\.?\s*BOX\b", text):
        add("po_box")
    inferred = False

    # RT / RW
    m = (re.search(r"\bRT\s*/?\s*RW\s*[:.]?\s*0*(\d{1,3})\s*[/\-]\s*0*(\d{1,3})\b", text)
         or re.search(r"\bRT\s*[./:]?\s*0*(\d{1,3})\s*[/,\- ]?\s*RW\s*[./:]?\s*0*(\d{1,3})\b", text))
    if m:
        a["rt"], a["rw"] = m.group(1), m.group(2)
        text = text[:m.start()] + " , " + text[m.end():]
    else:
        m = re.search(r"\bRT\s*[./:]?\s*0*(\d{1,3})\b", text)
        if m:
            a["rt"] = m.group(1)
            text = text[:m.start()] + " , " + text[m.end():]
        m = re.search(r"\bRW\s*[./:]?\s*0*(\d{1,3})\b", text)
        if m:
            a["rw"] = m.group(1)
            text = text[:m.start()] + " , " + text[m.end():]
    # Blok, Kav, Nomor
    m = re.search(r"\b(?:BLOK|BLK)\s*\.?\s*([A-Z]{0,2}\d{0,3}[A-Z]?(?:\s?[/\-]\s?\d+[A-Z]?)?)", text)
    if m and m.group(1):
        a["blok"] = m.group(1).replace(" ", "")
        text = text[:m.start()] + " , " + text[m.end():]
    m = re.search(r"\b(?:KAV|KAVLING)\s*\.?\s*([A-Z0-9/\-]+)", text)
    if m:
        a["blok"] = (a["blok"] + " KAV " + m.group(1)).strip()
        text = text[:m.start()] + " , " + text[m.end():]
    m = re.search(r"\bNO(?:MOR)?\s*[.:]?\s*([A-Z]?\d+[A-Z]?(?:\s?[/\-]\s?[A-Z0-9]+)?)", text)
    if m:
        a["nomor"] = m.group(1).replace(" ", "")
        text = text[:m.start()] + " , " + text[m.end():]
    # Lantai / Unit
    parts = []
    m = re.search(r"\b(?:LT|LANTAI)\s*\.?\s*(\d{1,3})\b", text)
    if m:
        parts.append("LT " + m.group(1))
        text = text[:m.start()] + " , " + text[m.end():]
    m = re.search(r"\bUNIT\s*\.?\s*([A-Z0-9/\-]+)", text)
    if m:
        parts.append("UNIT " + m.group(1))
        text = text[:m.start()] + " , " + text[m.end():]
    a["lantai_unit"] = " ".join(parts)
    # Kode pos
    m = re.search(r"(?:KODE\s*POS|KODEPOS|KD\s*POS)\s*[:.]?\s*(\d{4,6})", text)
    if m:
        pos = m.group(1)
        text = text[:m.start()] + " , " + text[m.end():]
    else:
        ms = [x for x in re.finditer(r"(?<![\d/\-])(\d{4,6})(?![\d/\-])", text)]
        pos = ""
        if ms:
            x = ms[-1]
            pos = x.group(1)
            text = text[:x.start()] + " , " + text[x.end():]
    if pos:
        if len(pos) != 5:
            add("kodepos_bukan_5_digit", f"kode pos '{pos}' bukan 5 digit")
        else:
            a["kodepos"] = pos
    text = re.sub(r"[./:()]", " ", text).replace("-", " ")
    tokens = [t for t in re.split(r"\s+|(?=,)|(?<=,)", text.replace(",", " , ")) if t]
    tokens = [t for t in tokens if t not in {"ADM", "ADMINISTRASI"}]

    # Jalan, komplek/gang, gedung
    i = 0
    while i < len(tokens):
        t = tokens[i]
        if t in STREET_JL and not a["jalan"]:
            seg, j = _take(tokens, i + 1, 8)
            a["jalan"] = " ".join(seg)
            tokens[i:j] = []
            continue
        if t in STREET_OTHER and not a["komplek_gang"]:
            seg, j = _take(tokens, i + 1, 6)
            a["komplek_gang"] = " ".join([t] + seg)
            tokens[i:j] = []
            continue
        if t in BUILDING and not a["gedung"]:
            seg, j = _take(tokens, i + 1, 5)
            a["gedung"] = " ".join([t] + seg)
            tokens[i:j] = []
            continue
        i += 1
    if a["jalan"] and not a["nomor"]:  # "JL MENTENG RAYA 3" -> nomor tanpa label NO
        m = re.match(r"^(.*[A-Z]{2}.*?)\s+(\d{1,3}[A-Z]?)$", a["jalan"])
        if m:
            a["jalan"], a["nomor"] = m.group(1), m.group(2)
            add("nomor_tanpa_label", "nomor rumah diambil dari angka di akhir nama jalan (tanpa label NO), verifikasi", "INFO")
    # Penanda administratif
    i = 0
    while i < len(tokens):
        t = tokens[i]
        if t in ADMIN:
            kind = ADMIN[t]
            seg, j = _take(tokens, i + 1, 4)
            if seg:
                if not a[kind]:
                    a[kind] = " ".join(seg)
                    if kind == "kota":
                        a["kota_tipe"] = "KOTA" if t in {"KOTA", "KOTAMADYA", "KODYA"} else "KABUPATEN"
                tokens[i:j] = []
                continue
        i += 1
    # Provinsi (tanpa penanda)
    if not a["provinsi"]:
        joined = " " + " ".join(tokens) + " "
        for alias, prov in PROV_ALIAS:
            k = joined.rfind(" " + alias + " ")
            if k >= 0:
                a["provinsi"] = prov
                joined = joined[:k] + " " + joined[k + len(alias) + 2:]
                tokens = joined.split()
                break
    else:
        for alias, prov in PROV_ALIAS:
            if alias == a["provinsi"] or prov == a["provinsi"]:
                a["provinsi"] = prov
                break
    # Kota (tanpa penanda)
    if not a["kota"]:
        joined = " " + " ".join(tokens) + " "
        for c in CITY_NAMES:
            k = joined.rfind(" " + c + " ")
            if k >= 0:
                a["kota"] = c
                joined = joined[:k] + " " + joined[k + len(c) + 2:]
                tokens = joined.split()
                break
    if a["kota"]:
        key = a["kota"].replace("KOTA ", "").replace("KABUPATEN ", "").replace("KAB ", "").strip()
        if key.startswith("JAKARTA"):
            a["kota_tipe"] = "KOTA ADMINISTRASI"
        elif key in AMBIG_KOTA_KAB and not a["kota_tipe"]:
            add("kota_atau_kab_tidak_jelas", sev="PERLU_CEK")
        if not a["provinsi"] and key in CITY_PROV:
            a["provinsi"] = CITY_PROV[key]
            add("diisi_dari_kota", f"provinsi diisi dari nama kota: {a['provinsi']}", "INFO")
    # Sisa teks -> tebak berdasarkan urutan (kelurahan, kecamatan, kota)
    segs = [s.strip() for s in " ".join(tokens).split(",") if s.strip()]
    guess_slots = [k for k in ("kota", "kecamatan", "kelurahan") if not a[k]]
    if a["jalan"] or a["komplek_gang"] or a["gedung"]:
        while segs and guess_slots and len(segs[-1].split()) <= 4 and len(segs) <= 3:
            a[guess_slots.pop(0)] = segs.pop()
            inferred = True
    a["sisa_teks"] = " | ".join(segs)
    if inferred:
        add("komponen_ditebak_dari_urutan")
    if segs:
        add("teks_sisa_tidak_terpetakan", sev="INFO")

    # Kelengkapan
    if not (a["jalan"] or a["komplek_gang"] or a["gedung"]):
        add("tidak_ada_jalan_atau_gedung")
    if not a["kota"]:
        add("kota_kosong")
    for comp, code in (("provinsi", "provinsi_kosong"), ("kecamatan", "kecamatan_kosong"),
                       ("kelurahan", "kelurahan_kosong"), ("kodepos", "kodepos_kosong")):
        if not a[comp] and not (comp == "kodepos" and any(c == "kodepos_bukan_5_digit" for _, c, _ in issues)):
            add(code, sev="PERLU_CEK")
    if (a["jalan"] or a["komplek_gang"]) and not (a["nomor"] or a["blok"] or a["gedung"]):
        add("nomor_rumah_kosong")
    if not a["rt"] and not a["rw"]:
        add("rt_rw_kosong")
    elif bool(a["rt"]) != bool(a["rw"]):
        add("rt_atau_rw_saja", sev="INFO")
    if len(re.sub(r"[^A-Z0-9]", "", text)) < 12:
        add("alamat_terlalu_pendek")
    # Kode pos vs provinsi (hanya aturan yang pasti: DKI = 10000-14999)
    if a["kodepos"] and a["provinsi"]:
        in_dki = 10000 <= int(a["kodepos"]) <= 14999
        if (a["provinsi"] == "DKI JAKARTA") != in_dki:
            add("kodepos_tidak_cocok_provinsi")
    if wilayah:
        wilayah.check(a, add)
        filled = {"provinsi_kosong": "provinsi", "kecamatan_kosong": "kecamatan", "kelurahan_kosong": "kelurahan",
                  "kodepos_kosong": "kodepos", "kota_kosong": "kota"}
        issues[:] = [x for x in issues if not (x[1] in filled and a[filled[x[1]]])]

    left = len(" ".join(segs).split())
    conf = "TINGGI" if not inferred and left <= 2 else ("SEDANG" if left <= 5 else "RENDAH")
    if inferred and conf == "TINGGI":
        conf = "SEDANG"
    return _finish(a, issues, conf, original)


def _finish(a, issues, conf, original):
    sev_rank = {"KRITIS": 0, "PERLU_CEK": 1, "INFO": 2}
    issues = sorted(set(issues), key=lambda x: (sev_rank[x[0]], x[1]))
    deliver = "NO" if any(s == "KRITIS" for s, _, _ in issues) else (
        "CHECK" if any(s == "PERLU_CEK" for s, _, _ in issues) else "YES")
    missing = [c.replace("_kosong", "") for _, c, _ in issues if c.endswith("_kosong") or c == "tidak_ada_jalan_atau_gedung"]
    return {**a, "deliverable": deliver, "confidence": conf,
            "missing": ",".join(missing), "notes": "; ".join(f"[{s}] {m}" for s, _, m in issues),
            "codes": [c for _, c, _ in issues]}


# =============================== CLI ===============================
def _get(r, spec):
    cols = spec if isinstance(spec, list) else [spec]
    return ", ".join(v for v in ((r.get(c, "") or "").strip() for c in cols if c) if v)


OUT_COLS = (["rec_id", "phone_norm", "phone_type", "phone_valid", "phone_notes", "email_norm", "email_valid",
             "email_notes", "email_suggestion"]
            + ["addr_" + k for k in ADDR_FIELDS if k != "sisa_teks"]
            + ["addr_sisa_teks", "addr_deliverable", "addr_confidence", "addr_missing", "addr_notes"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--map", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--wilayah")
    a = ap.parse_args()
    mp = json.load(open(a.map, encoding="utf-8"))
    wil = Wilayah(a.wilayah) if a.wilayah else None
    c = {"phone": Counter(), "email": Counter(), "addr": Counter(), "codes": Counter()}
    n = 0
    with open(a.inp, newline="", encoding="utf-8-sig") as f, \
            open(a.out, "w", newline="", encoding="utf-8") as g:
        w = csv.DictWriter(g, fieldnames=OUT_COLS)
        w.writeheader()
        for i, r in enumerate(csv.DictReader(f), start=1):
            n += 1
            p, e = phone_info(_get(r, mp.get("phone"))), email_info(_get(r, mp.get("email")))
            ad = parse_address(_get(r, mp.get("address")), wil)
            row = {"rec_id": _get(r, mp.get("rec_id")) or str(i), "phone_norm": p["norm"], "phone_type": p["type"],
                   "phone_valid": p["valid"], "phone_notes": ";".join(p["notes"]), "email_norm": e["norm"],
                   "email_valid": e["valid"], "email_notes": ";".join(e["notes"]), "email_suggestion": e["suggestion"],
                   "addr_deliverable": ad["deliverable"], "addr_confidence": ad["confidence"],
                   "addr_missing": ad["missing"], "addr_notes": ad["notes"], "addr_sisa_teks": ad["sisa_teks"]}
            row.update({"addr_" + k: ad[k] for k in ADDR_FIELDS if k != "sisa_teks"})
            w.writerow(row)
            c["phone"][p["valid"]] += 1
            c["email"][e["valid"]] += 1
            c["addr"][ad["deliverable"]] += 1
            c["codes"].update(ad["codes"] + p["notes"] + e["notes"])
    print(json.dumps({"rows": n, "phone_valid": dict(c["phone"]), "email_valid": dict(c["email"]),
                      "address_deliverable": dict(c["addr"]), "top_issue_codes": dict(c["codes"].most_common(12))},
                     indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
