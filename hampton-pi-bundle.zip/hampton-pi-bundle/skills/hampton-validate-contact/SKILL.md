---
name: hampton-validate-contact
description: Validasi no HP, email, dan alamat rumah nasabah Project Hampton (HSBC -> OCBC) sebelum welcome pack dikirim, serta memecah alamat free-text menjadi komponen (jalan, nomor, RT, RW, kelurahan/desa, kecamatan, kota/kabupaten, provinsi, kode pos) dengan catatan bagian yang kurang. Gunakan setiap kali user menyebut validasi HP/email/alamat, pecah atau rapikan alamat, kelengkapan alamat, alamat bisa dikirim atau tidak, kode pos, RT/RW, kecamatan, kelurahan, atau data kontak nasabah hampton, meskipun user tidak menyebut kata "skill". Untuk pencocokan/dedup nasabah gunakan skill hampton-dedup.
---

# Hampton Validate Contact

Tujuan: pastikan HP, email, dan alamat nasabah HSBC bisa dipakai untuk mengirim welcome pack, dan alamat free text terpecah rapi ke komponen. Konteks project ada di AGENTS.md. Dedup/matching bukan bagian skill ini (lihat `hampton-dedup`).

## Cara jalan
```
python scripts/validate_contact.py --in <file.csv> --map mapping_contact.json --out contact_check.csv [--wilayah wilayah.csv]
python scripts/test_contact.py
```
`mapping_contact.json`: salin dari `examples/mapping_contact.example.json`. Field `address` boleh satu kolom atau daftar kolom (digabung).

## Output
- **HP**: `phone_norm` (62xxx), `phone_type` (mobile/landline/foreign), `phone_valid` YES/NO/CHECK, `phone_notes`. Ditandai: dummy/berulang, terlalu pendek/panjang, prefix operator tidak dikenal, beberapa nomor dalam satu field.
- **Email**: `email_norm`, `email_valid`, `email_notes`, `email_suggestion` (usulan perbaikan typo domain). Ditandai: format salah, placeholder, domain typo, email sekali pakai.
- **Alamat**: `addr_jalan`, `addr_komplek_gang`, `addr_nomor`, `addr_blok`, `addr_gedung`, `addr_lantai_unit`, `addr_rt`, `addr_rw`, `addr_kelurahan`, `addr_kecamatan`, `addr_kota`, `addr_kota_tipe`, `addr_provinsi`, `addr_kodepos`, `addr_sisa_teks`.
- **Kelengkapan alamat**: `addr_deliverable` (YES/CHECK/NO), `addr_missing` (bagian yang kurang), `addr_notes`, `addr_confidence` (TINGGI/SEDANG/RENDAH).
  - `KRITIS` -> NO: alamat kosong/placeholder, tanpa jalan/komplek/gedung, tanpa kota.
  - `PERLU_CEK` -> CHECK: kode pos, kecamatan, kelurahan, provinsi, nomor rumah tidak ada; kode pos tidak cocok provinsi; komponen ditebak dari urutan; kota vs kabupaten tidak jelas.
  - `INFO`: RT/RW tidak ada, komponen diisi dari referensi.

## Tabel referensi wilayah (`--wilayah`)
Sangat disarankan. CSV kolom: `provinsi,kota,kecamatan,kelurahan,kodepos`, dari sumber resmi (mis. kode wilayah Kemendagri/BPS, data kode pos Pos Indonesia; minta user menyediakan). Dengan tabel ini script memeriksa nama wilayah, mengusulkan koreksi typo, mengisi komponen yang hilang, dan mengecek kode pos vs kelurahan. Jangan mengarang data wilayah. `examples/wilayah.example.csv` hanya contoh format.

## Batasan (jangan diklaim lebih)
Ini validasi **format dan kelengkapan**, bukan bukti nomor aktif, email bisa menerima surat, atau alamat benar-benar ada. Verifikasi eksternal (OTP/HLR, cek MX, geocoding, API vendor) melibatkan PII dan hanya dengan persetujuan user. Parser alamat berbasis aturan teks: lakukan QA sampel dan tambahkan kasus yang salah ke `test_contact.py`.

## Alur kerja
1. Profil dulu: berapa kolom alamat, null rate, contoh format. 2. Mapping kolom. 3. Jalankan (dengan `--wilayah` bila ada). 4. QA sampel ~100 alamat per `addr_deliverable` dan per `addr_confidence` RENDAH. 5. Laporan: jumlah per status, top issue codes, bagian alamat yang paling sering kurang.

## Guardrail data (wajib)
Data nasabah = PII + rahasia bank. Proses lokal; jangan upload ke layanan eksternal; jangan commit ke git. Jangan tampilkan HP/email/alamat mentah di chat atau log (mask atau agregat). Output CSV berisi PII: simpan di lokasi aman. Jangan menimpa file sumber.

## Detail
`references/address-contact-rules.md`: urutan ekstraksi alamat, penanda yang dikenali, aturan kode pos, kasus yang belum ditangani, ide lanjutan.
