# Aturan validasi kontak dan alamat - Hampton

## Alamat, HP, email (`scripts/validate_contact.py`)
- **Urutan ekstraksi alamat**: RT/RW -> blok/kav/nomor -> lantai/unit -> kode pos -> jalan/komplek/gedung -> penanda administratif (Kel/Desa/Kec/Kab/Kota/Prov) -> provinsi dan kota tanpa penanda -> sisa teks ditebak dari urutan (kelurahan, kecamatan, kota) dan diberi catatan "ditebak".
- Penanda yang dikenali: JL/JALAN/JLN, GG/GANG, KOMP/KOMPLEK, PERUM/PERUMAHAN, CLUSTER, KP/KAMPUNG, DUSUN, APARTEMEN/APT/RUSUN/MENARA/GEDUNG/TOWER, KEL/KELURAHAN/DESA/DS, KEC/KECAMATAN, KAB/KABUPATEN/KOTA/KODYA, PROV/PROVINSI, singkatan provinsi (JABAR, NTT, DIY, ...). 38 provinsi termasuk provinsi Papua hasil pemekaran.
- **Aturan kode pos yang pasti**: 5 digit; DKI Jakarta = 10000-14999. Aturan lain butuh tabel referensi, jadi tidak ditebak.
- **Kota vs kabupaten**: nama seperti Bogor, Bekasi, Tangerang, Bandung ada sebagai kota dan kabupaten. Tanpa penanda "Kota/Kab" diberi catatan, jangan ditebak.
- **Nomor rumah tanpa label NO** ("Jl. Menteng Raya 3") diambil dari angka di akhir nama jalan dengan catatan INFO; nama jalan berangka seperti "Jl. 17 Agustus 1945" rentan salah, makanya dibatasi maksimal 3 digit.
- **Yang belum ditangani / perlu QA**: alamat bahasa Inggris, alamat luar negeri, alamat tanpa pemisah dengan nama dusun/kampung yang panjang, singkatan lokal, landmark ("depan Indomaret"), dan nama jalan yang mengandung nama provinsi/kota. Tambahkan kasus nyata yang salah ke `test_contact.py`.
- **Validasi lanjutan (butuh persetujuan karena PII/jaringan)**: cek MX domain email (hanya domain, tanpa local-part), HLR/OTP untuk HP, geocoding atau validasi alamat oleh vendor. Jangan jalankan tanpa izin Bagas.
- **Alamat sebagai penguat dedup**: alamat sama (setelah dipecah per komponen) bisa jadi sinyal tertiary tambahan, tapi jangan jadi primary karena keluarga sering satu alamat.
