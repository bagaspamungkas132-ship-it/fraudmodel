# Pasang bundle Hampton di Pi

1. skills/  -> salin dua folder ke ~/.pi/agent/skills/  (atau .pi/skills/ di folder project)
2. agents/  -> salin dua file .md ke ~/.pi/agent/agents/ (atau .pi/agents/ di folder project). Butuh extension sub-agent Pi yang sudah terpasang.
3. AGENTS.md -> taruh di root folder project Hampton.
4. Jalankan tes:  python skills/hampton-dedup/scripts/test_namematch.py  dan  python skills/hampton-validate-contact/scripts/test_contact.py
5. Cek nama field di frontmatter agent (tools, skills) cocok dengan extension sub-agent yang kamu pakai; sesuaikan bila beda.
